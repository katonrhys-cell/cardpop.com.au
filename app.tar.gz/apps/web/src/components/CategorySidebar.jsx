import React, { useState } from 'react';
import { Search, ChevronDown, Check, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { cn } from '@/lib/utils';

const CategorySidebar = ({ 
  categories = [], 
  selectedCategory, 
  onSelectCategory, 
  searchQuery, 
  onSearchChange, 
  className = '' 
}) => {
  const [open, setOpen] = useState(false);

  return (
    <div className={`w-full bg-card border border-border rounded-2xl shadow-sm p-5 ${className}`}>
      <div className="flex items-center gap-2 mb-6 pb-4 border-b border-border">
        <Filter className="w-5 h-5 text-primary" />
        <h2 className="font-heading font-bold text-lg">Filters</h2>
      </div>

      <div className="space-y-6">
        {/* Search Input */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2.5 block">
            Search Products
          </label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search by name..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-9 bg-background h-11 rounded-xl text-foreground"
            />
          </div>
        </div>

        {/* Category Combobox */}
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2.5 block">
            Category
          </label>
          <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                role="combobox"
                aria-expanded={open}
                className="w-full justify-between bg-background h-11 rounded-xl font-normal"
              >
                <span className="truncate">
                  {selectedCategory ? selectedCategory : "All Categories"}
                </span>
                <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[calc(100%-2rem)] md:w-64 p-0 rounded-xl" align="start">
              <Command>
                <CommandInput placeholder="Search category..." className="h-11" />
                <CommandList className="max-h-[300px] overflow-y-auto">
                  <CommandEmpty>No category found.</CommandEmpty>
                  <CommandGroup>
                    <CommandItem
                      onSelect={() => {
                        onSelectCategory('');
                        setOpen(false);
                      }}
                      className="cursor-pointer py-2.5"
                    >
                      <Check className={cn("mr-2 h-4 w-4 text-primary", selectedCategory === '' ? "opacity-100" : "opacity-0")} />
                      All Categories
                    </CommandItem>
                    {categories.map((category) => (
                      <CommandItem
                        key={category}
                        onSelect={() => {
                          onSelectCategory(category);
                          setOpen(false);
                        }}
                        className="cursor-pointer py-2.5"
                      >
                        <Check className={cn("mr-2 h-4 w-4 text-primary", selectedCategory === category ? "opacity-100" : "opacity-0")} />
                        {category}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        </div>
      </div>
    </div>
  );
};

export default CategorySidebar;