
import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import pb from '@/lib/pocketbaseClient.js';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Loader2, X, ImagePlus, AlertCircle, Sparkles } from 'lucide-react';
import { useCardAnalysis } from '@/hooks/useCardAnalysis.js';
import { useProductSelectors } from '@/hooks/useProductSelectors.js';

const INITIAL_STATE = {
  cardName: '',
  condition: 'Mint',
  estimatedValue: '',
  description: '',
  listingStatus: 'Not Listed',
  askingPrice: '',
  tradeValue: '',
  listedForTrade: false,
  listedForSale: false,
};

const CardUploadForm = ({ card, onSuccess, onCancel }) => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState(INITIAL_STATE);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [previewUrls, setPreviewUrls] = useState([]);
  const [imagesToDelete, setImagesToDelete] = useState([]);
  const [isAutoFilled, setIsAutoFilled] = useState(false);
  
  // AI Preview Dialog State
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);
  const [editableAnalysis, setEditableAnalysis] = useState(null);

  const fileInputRef = useRef(null);

  const { analyzeCardImage, isAnalyzing, analysisResult, clearAnalysis } = useCardAnalysis();

  const {
    brands,
    categories,
    filteredSubcategories,
    filteredProductLines,
    selectedBrand,
    selectedCategory,
    selectedSubcategory,
    selectedProductLine,
    setBrand,
    setCategory,
    setSubcategory,
    setProductLine,
    clearSubcategory,
    clearProductLine,
    loading: selectorsLoading
  } = useProductSelectors({
    brandId: card?.brandId || '',
    categoryId: card?.categoryId || '',
    subcategoryId: card?.subcategoryId || '',
    productLineId: card?.productLineId || ''
  });

  useEffect(() => {
    if (card) {
      setFormData({
        cardName: card.cardName ?? '',
        condition: card.condition ?? 'Mint',
        estimatedValue: card.estimatedValue ?? '',
        description: card.description ?? '',
        listingStatus: card.listingStatus ?? 'Not Listed',
        askingPrice: card.askingPrice ?? '',
        tradeValue: card.tradeValue ?? '',
        listedForTrade: card.listedForTrade ?? false,
        listedForSale: card.listedForSale ?? false,
      });
      
      if (card.cardImage) {
        const images = Array.isArray(card.cardImage) ? card.cardImage : [card.cardImage];
        const urls = images.map(img => pb.files.getUrl(card, img));
        setPreviewUrls(urls);
        setSelectedFiles(images.map(img => ({ isExisting: true, filename: img })));
      }
    } else {
      setFormData(INITIAL_STATE);
      setSelectedFiles([]);
      setPreviewUrls([]);
      setImagesToDelete([]);
      setIsAutoFilled(false);
      clearAnalysis();
    }
  }, [card, clearAnalysis]);

  // Handle opening the AI review dialog once analysis completes
  useEffect(() => {
    if (analysisResult && !isReviewDialogOpen) {
      setEditableAnalysis({
        cardName: analysisResult.name || analysisResult.cardName || '',
        condition: analysisResult.mappedCondition || 'Good',
        estimatedValue: analysisResult.price ? String(analysisResult.price) : '',
        description: [analysisResult.description, analysisResult.details].filter(Boolean).join('\n\n') || '',
      });
      setIsReviewDialogOpen(true);
    }
  }, [analysisResult, isReviewDialogOpen]);

  const handleApplyAI = () => {
    setFormData(prev => ({
      ...prev,
      cardName: editableAnalysis.cardName || prev.cardName,
      condition: editableAnalysis.condition || prev.condition,
      estimatedValue: editableAnalysis.estimatedValue || prev.estimatedValue,
      description: editableAnalysis.description || prev.description
    }));
    setIsAutoFilled(true);
    setIsReviewDialogOpen(false);
    clearAnalysis();
    toast.success("Fields auto-populated successfully. Review them below.");
  };

  const handleCancelAI = () => {
    setIsReviewDialogOpen(false);
    clearAnalysis();
  };

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    const totalFiles = selectedFiles.length + files.length;
    if (totalFiles > 2) {
      toast.error('You can only upload up to 2 images per card.');
      return;
    }

    const validFiles = [];
    const newPreviewUrls = [];

    for (const file of files) {
      if (file.size > 20971520) {
        toast.error(`Image ${file.name} exceeds the 20MB limit.`);
        continue;
      }
      validFiles.push(file);
      newPreviewUrls.push(URL.createObjectURL(file));
    }

    setSelectedFiles(prev => [...prev, ...validFiles]);
    setPreviewUrls(prev => [...prev, ...newPreviewUrls]);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeFile = (index) => {
    const fileToRemove = selectedFiles[index];
    if (fileToRemove?.isExisting) {
      setImagesToDelete(prev => [...prev, fileToRemove.filename]);
    }
    
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
    setPreviewUrls(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.cardName.trim()) {
      toast.error('Card Name is required');
      return;
    }
    if (!formData.estimatedValue || isNaN(formData.estimatedValue)) {
      toast.error('A valid Estimated Value is required');
      return;
    }
    if (!currentUser) {
      toast.error('You must be logged in to add a card');
      return;
    }
    if (!currentUser.emailVerified) {
      toast.error('Email verification required. Please verify your email before adding cards to your vault.');
      return;
    }

    setLoading(true);
    try {
      const submitData = new FormData();
      
      if (!card) {
        submitData.append('owner', currentUser.id);
      }

      submitData.append('cardName', formData.cardName.trim());
      submitData.append('condition', formData.condition);
      submitData.append('estimatedValue', parseFloat(formData.estimatedValue));
      submitData.append('listingStatus', formData.listingStatus);
      
      // Append taxonomy IDs (now optional)
      if (selectedBrand) submitData.append('brandId', selectedBrand);
      if (selectedCategory) submitData.append('categoryId', selectedCategory);
      if (selectedSubcategory) submitData.append('subcategoryId', selectedSubcategory);
      if (selectedProductLine) submitData.append('productLineId', selectedProductLine);
      
      if (formData.description) submitData.append('description', formData.description.trim());
      
      if (formData.listingStatus === 'For Sale' || formData.listingStatus === 'For Both') {
        submitData.append('listedForSale', true);
        if (formData.askingPrice) submitData.append('askingPrice', parseFloat(formData.askingPrice));
      } else {
        submitData.append('listedForSale', false);
        submitData.append('askingPrice', '');
      }

      if (formData.listingStatus === 'For Trade' || formData.listingStatus === 'For Both') {
        submitData.append('listedForTrade', true);
        if (formData.tradeValue) submitData.append('tradeValue', parseFloat(formData.tradeValue));
      } else {
        submitData.append('listedForTrade', false);
        submitData.append('tradeValue', '');
      }

      selectedFiles.forEach((file) => {
        if (!file.isExisting) {
          submitData.append('cardImage', file);
        }
      });

      if (card) {
        await pb.collection('cards').update(card.id, submitData, { $autoCancel: false });
        toast.success('Card updated successfully!');
      } else {
        await pb.collection('cards').create(submitData, { $autoCancel: false });
        toast.success('Card successfully added to your vault!');
      }
      
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error("PocketBase Submission Error:", error);
      toast.error(error.message || 'Failed to save card. Please check your entries.');
    } finally {
      setLoading(false);
    }
  };

  const fileToAnalyze = selectedFiles.find(f => !f.isExisting);

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-8 bg-card text-card-foreground">
        
        {!currentUser?.emailVerified && (
          <div className="bg-destructive/10 border border-destructive/20 text-destructive p-4 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">Email Verification Required</p>
              <p className="text-xs opacity-90">You must verify your email address before you can add cards to your vault.</p>
            </div>
          </div>
        )}

        <div className="space-y-4 bg-secondary/50 p-6 rounded-2xl border border-border">
          <div className="flex items-center justify-between">
            <Label className="text-base font-bold text-foreground">Card Images (Up to 2)</Label>
            <span className="text-sm text-muted-foreground font-medium">{previewUrls.length} / 2 uploaded</span>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {previewUrls.map((url, index) => (
              <div key={index} className="relative w-full aspect-[3/4] rounded-xl overflow-hidden border border-border bg-background shadow-sm group">
                <img src={url} alt={`Preview ${index + 1}`} className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => removeFile(index)}
                  className="absolute top-2 right-2 bg-black/60 hover:bg-destructive text-white p-1.5 rounded-lg transition-colors backdrop-blur-sm opacity-0 group-hover:opacity-100"
                >
                  <X size={16} />
                </button>
                <div className="absolute bottom-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded-md backdrop-blur-sm font-medium">
                  {index === 0 ? 'Front' : 'Back'}
                </div>
              </div>
            ))}

            {previewUrls.length < 2 && (
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="w-full aspect-[3/4] border-2 border-dashed border-border hover:border-primary/50 hover:bg-muted/50 transition-all rounded-xl flex flex-col items-center justify-center cursor-pointer bg-background text-muted-foreground"
              >
                <ImagePlus className="w-8 h-8 mb-3 opacity-50" />
                <p className="font-bold text-sm text-foreground mb-1">Add Image</p>
                <p className="text-xs">JPEG, PNG, WEBP (Max 20MB)</p>
              </div>
            )}
          </div>
          
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept="image/jpeg, image/png, image/webp, image/gif" 
            multiple
            className="hidden" 
          />

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <Button
              type="button"
              variant="secondary"
              onClick={() => analyzeCardImage(fileToAnalyze)}
              disabled={isAnalyzing || !fileToAnalyze}
              className="w-full sm:w-auto bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 transition-all font-semibold rounded-xl"
            >
              {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Sparkles className="w-4 h-4 mr-2" />}
              {isAnalyzing ? 'Analyzing Image...' : 'AI Scan Image'}
            </Button>
            
            {!fileToAnalyze && selectedFiles.length > 0 && (
              <p className="text-xs text-muted-foreground">Upload a new image to scan it with AI.</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6">
          <div className="space-y-5 md:col-span-2 relative">
            {isAutoFilled && (
              <div className="absolute top-0 right-0 flex items-center text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-md">
                <Sparkles className="w-3 h-3 mr-1" />
                AI Auto-filled
              </div>
            )}
            <h3 className="font-bold text-lg text-foreground border-b border-border pb-2">Basic Information</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Card Name <span className="text-destructive">*</span></Label>
                <Input 
                  required 
                  value={formData.cardName} 
                  onChange={(e) => handleInputChange('cardName', e.target.value)} 
                  placeholder="e.g. Charizard Holographic" 
                  className={`bg-background text-foreground transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`} 
                />
              </div>

              <div className="space-y-2">
                <Label>Condition <span className="text-destructive">*</span></Label>
                <Select value={formData.condition} onValueChange={(v) => handleInputChange('condition', v)}>
                  <SelectTrigger className={`bg-background transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Mint">Mint</SelectItem>
                    <SelectItem value="Near Mint">Near Mint</SelectItem>
                    <SelectItem value="Excellent">Excellent</SelectItem>
                    <SelectItem value="Good">Good</SelectItem>
                    <SelectItem value="Fair">Fair</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Brand</Label>
                  {selectedBrand && (
                    <button type="button" onClick={() => setBrand('')} className="text-xs text-muted-foreground hover:text-foreground">Clear</button>
                  )}
                </div>
                <Select value={selectedBrand} onValueChange={setBrand} disabled={selectorsLoading}>
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Select Brand" />
                  </SelectTrigger>
                  <SelectContent>
                    {brands.map(b => (
                      <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Category</Label>
                  {selectedCategory && (
                    <button type="button" onClick={() => setCategory('')} className="text-xs text-muted-foreground hover:text-foreground">Clear</button>
                  )}
                </div>
                <Select value={selectedCategory} onValueChange={setCategory} disabled={selectorsLoading}>
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Select Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Product Line</Label>
                  {selectedProductLine && (
                    <button type="button" onClick={clearProductLine} className="text-xs text-muted-foreground hover:text-foreground">Clear</button>
                  )}
                </div>
                <Select value={selectedProductLine} onValueChange={setProductLine} disabled={!selectedBrand || selectorsLoading}>
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder={selectedBrand ? "Select Product Line" : "Select Brand first"} />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredProductLines.map(pl => (
                      <SelectItem key={pl.id} value={pl.id}>{pl.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Subcategory</Label>
                  {selectedSubcategory && (
                    <button type="button" onClick={clearSubcategory} className="text-xs text-muted-foreground hover:text-foreground">Clear</button>
                  )}
                </div>
                <Select value={selectedSubcategory} onValueChange={setSubcategory} disabled={!selectedCategory || selectorsLoading}>
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder={selectedCategory ? "Select Subcategory" : "Select Category first"} />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredSubcategories.map(sub => (
                      <SelectItem key={sub.id} value={sub.id}>{sub.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Estimated Value ($) <span className="text-destructive">*</span></Label>
                <Input 
                  required 
                  type="number" 
                  step="0.01" 
                  min="0" 
                  value={formData.estimatedValue} 
                  onChange={(e) => handleInputChange('estimatedValue', e.target.value)} 
                  placeholder="0.00" 
                  className={`bg-background text-foreground tabular-nums transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`} 
                />
              </div>
            </div>
          </div>

          <div className="space-y-5 md:col-span-2">
            <h3 className="font-bold text-lg text-foreground border-b border-border pb-2">Market Status</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Listing Status <span className="text-destructive">*</span></Label>
                <Select value={formData.listingStatus} onValueChange={(v) => {
                  handleInputChange('listingStatus', v);
                }}>
                  <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Not Listed">Not Listed</SelectItem>
                    <SelectItem value="For Trade">For Trade</SelectItem>
                    <SelectItem value="For Sale">For Sale</SelectItem>
                    <SelectItem value="For Both">For Both</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {(formData.listingStatus === 'For Sale' || formData.listingStatus === 'For Both') && (
                <div className="space-y-2">
                  <Label>Asking Price ($)</Label>
                  <Input type="number" step="0.01" min="0" value={formData.askingPrice} onChange={(e) => handleInputChange('askingPrice', e.target.value)} placeholder="0.00" className="bg-background text-foreground tabular-nums" />
                </div>
              )}

              {(formData.listingStatus === 'For Trade' || formData.listingStatus === 'For Both') && (
                <div className="space-y-2">
                  <Label>Trade Value ($)</Label>
                  <Input type="number" step="0.01" min="0" value={formData.tradeValue} onChange={(e) => handleInputChange('tradeValue', e.target.value)} placeholder="0.00" className="bg-background text-foreground tabular-nums" />
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label>Card Description / Notes</Label>
            <Textarea 
              value={formData.description} 
              onChange={(e) => handleInputChange('description', e.target.value)} 
              placeholder="Add any specific details, centering notes, or historical context about this card..."
              className={`min-h-[100px] resize-y bg-background text-foreground transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`}
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-6 border-t border-border">
          {onCancel && (
            <Button type="button" variant="ghost" onClick={onCancel} disabled={loading} className="rounded-xl">
              Cancel
            </Button>
          )}
          <Button 
            type="submit" 
            disabled={loading || !currentUser?.emailVerified} 
            className="min-w-[140px] font-bold rounded-xl active:scale-[0.98] transition-transform shadow-md"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
            {loading ? 'Saving...' : card ? 'Update Card' : 'Save to Vault'}
          </Button>
        </div>
      </form>

      {/* AI Review Dialog */}
      <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl bg-background border-border">
          <DialogHeader>
            <DialogTitle className="font-serif text-xl flex items-center">
              <Sparkles className="w-5 h-5 mr-2 text-primary" />
              Review Extracted Data
            </DialogTitle>
            <DialogDescription>
              Review and edit the data extracted by AI before applying it to your form.
            </DialogDescription>
          </DialogHeader>
          
          {editableAnalysis && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Product Name</Label>
                <Input 
                  value={editableAnalysis.cardName} 
                  onChange={e => setEditableAnalysis({...editableAnalysis, cardName: e.target.value})} 
                  className="bg-muted/50 rounded-xl"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Condition</Label>
                  <Select value={editableAnalysis.condition} onValueChange={v => setEditableAnalysis({...editableAnalysis, condition: v})}>
                    <SelectTrigger className="bg-muted/50 rounded-xl"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Mint">Mint</SelectItem>
                      <SelectItem value="Near Mint">Near Mint</SelectItem>
                      <SelectItem value="Excellent">Excellent</SelectItem>
                      <SelectItem value="Good">Good</SelectItem>
                      <SelectItem value="Fair">Fair</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Estimated Value ($)</Label>
                  <Input 
                    type="number" 
                    step="0.01" 
                    value={editableAnalysis.estimatedValue} 
                    onChange={e => setEditableAnalysis({...editableAnalysis, estimatedValue: e.target.value})} 
                    className="bg-muted/50 rounded-xl tabular-nums"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Description & Details</Label>
                <Textarea 
                  value={editableAnalysis.description} 
                  onChange={e => setEditableAnalysis({...editableAnalysis, description: e.target.value})} 
                  className="bg-muted/50 rounded-xl min-h-[100px] resize-y"
                />
              </div>
            </div>
          )}
          
          <DialogFooter className="border-t border-border pt-4">
            <Button variant="outline" onClick={handleCancelAI} className="rounded-xl">Cancel</Button>
            <Button onClick={handleApplyAI} className="rounded-xl font-bold">Apply Data</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CardUploadForm;
