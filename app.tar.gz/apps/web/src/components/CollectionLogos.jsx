
import React from 'react';
import { 
  Zap, Flame, Ghost, Hexagon, Shield, 
  Trophy, Target, Activity, Crosshair, Medal, 
  Dumbbell, Crown, Star, Swords, Gamepad2
} from 'lucide-react';

export const PokemonLogo = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path d="M2.5 12h6.5" />
    <path d="M15 12h6.5" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

export const MagicLogo = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 2.5s-4 4.5-4 10a4 4 0 0 0 8 0c0-5.5-4-10-4-10z" />
    <path d="M12 14.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z" />
  </svg>
);

export const YuGiOhLogo = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
    <circle cx="12" cy="12" r="3" />
    <path d="M12 2v3" />
    <path d="M12 19v3" />
  </svg>
);

export const BasketballLogo = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path d="M5.636 5.636a9 9 0 0 1 12.728 12.728" />
    <path d="M18.364 5.636a9 9 0 0 0-12.728 12.728" />
    <path d="M12 2v20" />
    <path d="M2 12h20" />
  </svg>
);

export const FootballLogo = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M5 19c-2-2-2-6 0-10l4-4c4-2 8-2 10 0 2 2 2 6 0 10l-4 4c-4 2-8 2-10 0Z" />
    <path d="M8 8l8 8" />
    <path d="M11 9l2 2" />
    <path d="M13 11l2 2" />
  </svg>
);

export const BaseballLogo = ({ className = "w-5 h-5" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path d="M5 5c3.5 3.5 3.5 9.5 0 14" />
    <path d="M19 5c-3.5 3.5-3.5 9.5 0 14" />
  </svg>
);

export const TradingCardGamesLogo = ({ className = "w-5 h-5" }) => (
  <Gamepad2 className={className} color="#e81cff" />
);

export const SportingCardsLogo = ({ className = "w-5 h-5" }) => (
  <Trophy className={className} color="#E63946" />
);

export const getCollectionLogo = (name, props = { className: "w-5 h-5" }) => {
  switch (name) {
    case 'Trading Card Games':
      return <TradingCardGamesLogo {...props} />;
    case 'Sporting Cards':
      return <SportingCardsLogo {...props} />;
    case 'Pokemon':
      return <PokemonLogo {...props} />;
    case 'Magic':
    case 'Magic: The Gathering':
      return <MagicLogo {...props} />;
    case 'Yu-Gi-Oh':
    case 'Yu Gi Oh!':
      return <YuGiOhLogo {...props} />;
    case 'NBA':
    case 'NBL':
      return <BasketballLogo {...props} />;
    case 'NFL':
      return <FootballLogo {...props} />;
    case 'Baseball':
    case 'MLB':
      return <BaseballLogo {...props} />;
    case 'Digimon': return <Activity {...props} />;
    case 'Riftbound': return <Ghost {...props} />;
    case 'TMNT': return <Target {...props} />;
    case 'Final Fantasy': return <Swords {...props} />;
    case 'Disney Lorcana': return <Star {...props} />;
    case 'One Piece': return <Crown {...props} />;
    case 'NHL': return <Crosshair {...props} />;
    case 'Cricket': return <Target {...props} />;
    case 'NRL': return <Shield {...props} />;
    case 'Formula 1': return <Activity {...props} />;
    case 'Wrestling': return <Dumbbell {...props} />;
    case 'Golf': return <Target {...props} />;
    case 'Soccer': return <Hexagon {...props} />;
    case 'AFL': return <Shield {...props} />;
    case 'Tennis': return <Activity {...props} />;
    case 'UFC': return <Dumbbell {...props} />;
    default:
      return <Medal {...props} />;
  }
};

export const getCollectionColorVar = (name) => {
  const map = {
    'Pokemon': '--color-pokemon',
    'Digimon': '--color-digimon',
    'Magic': '--color-magic',
    'Magic: The Gathering': '--color-magic',
    'Yu-Gi-Oh': '--color-yugioh',
    'Yu Gi Oh!': '--color-yugioh',
    'Riftbound': '--color-riftbound',
    'One Piece': '--color-onepiece',
    'Disney Lorcana': '--color-disney',
    'Final Fantasy': '--color-finalfantasy',
    'NBL': '--color-nbl',
    'NBA': '--color-nba',
    'NHL': '--color-nhl',
    'Baseball': '--color-baseball',
    'NFL': '--color-nfl',
    'Cricket': '--color-cricket',
    'NRL': '--color-nrl',
    'Formula 1': '--color-formula1',
    'Golf': '--color-golf',
    'Soccer': '--color-soccer',
    'AFL': '--color-afl',
    'Tennis': '--color-tennis',
    'Wrestling': '--color-wrestling',
    'UFC': '--color-ufc',
  };
  return map[name] || '--primary';
};

export const CollectionLogo = ({ name, className = "", size = 20 }) => {
  const colorVar = getCollectionColorVar(name);
  
  return (
    <div 
      className={`flex items-center justify-center rounded-lg ${className}`} 
      style={{ width: size * 1.8, height: size * 1.8, backgroundColor: `hsla(var(${colorVar}) / 0.1)` }}
    >
      {getCollectionLogo(name, { 
        className: `w-5 h-5`, 
        style: { width: size, height: size, color: `hsl(var(${colorVar}))` } 
      })}
    </div>
  );
};

export default CollectionLogo;
