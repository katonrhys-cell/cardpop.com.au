import React from 'react';
import { Card } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { CreditCard, Wallet, Smartphone } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const PaymentMethodSelector = ({ value, onChange, onNext, onBack }) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (value) onNext();
  };

  return (
    <Card className="premium-card p-6 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6 border-b border-border pb-4">
        <h2 className="font-serif text-2xl font-bold flex items-center gap-2">
          <CreditCard className="w-6 h-6 text-primary" />
          Payment Method
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <RadioGroup value={value} onValueChange={onChange} className="space-y-4">
          
          <Label htmlFor="stripe" className="cursor-pointer">
            <div className={`p-4 rounded-xl border-2 transition-all flex items-center justify-between ${value === 'stripe' ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/50'}`}>
              <div className="flex items-center gap-3">
                <RadioGroupItem value="stripe" id="stripe" />
                <CreditCard className="w-5 h-5 text-muted-foreground" />
                <div className="font-semibold text-base">Credit or Debit Card</div>
              </div>
              <Badge variant="secondary" className="bg-background">Stripe</Badge>
            </div>
          </Label>

          <Label htmlFor="wallet" className="cursor-pointer">
            <div className={`p-4 rounded-xl border-2 transition-all flex items-center justify-between ${value === 'wallet' ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/50'}`}>
              <div className="flex items-center gap-3">
                <RadioGroupItem value="wallet" id="wallet" />
                <Smartphone className="w-5 h-5 text-muted-foreground" />
                <div className="font-semibold text-base">Digital Wallet</div>
              </div>
              <div className="flex gap-2">
                <Badge variant="outline">Apple Pay</Badge>
                <Badge variant="outline">G Pay</Badge>
              </div>
            </div>
          </Label>

          <Label htmlFor="razorpay" className="cursor-pointer">
            <div className={`p-4 rounded-xl border-2 transition-all flex items-center justify-between ${value === 'razorpay' ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/50'}`}>
              <div className="flex items-center gap-3">
                <RadioGroupItem value="razorpay" id="razorpay" />
                <Wallet className="w-5 h-5 text-muted-foreground" />
                <div className="font-semibold text-base">Alternative Payments</div>
              </div>
              <Badge variant="secondary" className="bg-background">Razorpay</Badge>
            </div>
          </Label>

        </RadioGroup>

        <div className="pt-6 flex justify-between items-center border-t border-border">
          <Button type="button" variant="ghost" onClick={onBack}>Back to Billing</Button>
          <Button type="submit" size="lg" className="rounded-full px-8" disabled={!value}>Review Order</Button>
        </div>
      </form>
    </Card>
  );
};

export default PaymentMethodSelector;