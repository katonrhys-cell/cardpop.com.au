import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Ticket } from 'lucide-react';
import { toast } from 'sonner';

const PromoCodeInput = ({ onApply }) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);

  const handleApply = (e) => {
    e.preventDefault();
    if (!code.trim()) return;

    setLoading(true);
    // Simulate API validation
    setTimeout(() => {
      const c = code.toUpperCase();
      if (c === 'SAVE10') {
        onApply(0.10, c);
        toast.success('Promo code applied: 10% off');
      } else if (c === 'SAVE20') {
        onApply(0.20, c);
        toast.success('Promo code applied: 20% off');
      } else {
        toast.error('Invalid promo code');
      }
      setCode('');
      setLoading(false);
    }, 600);
  };

  return (
    <form onSubmit={handleApply} className="flex gap-2">
      <div className="relative flex-1">
        <Ticket className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input 
          type="text" 
          placeholder="Enter promo code (e.g. SAVE10)" 
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="pl-9"
          disabled={loading}
        />
      </div>
      <Button type="submit" disabled={!code.trim() || loading} variant="secondary">
        Apply
      </Button>
    </form>
  );
};

export default PromoCodeInput;