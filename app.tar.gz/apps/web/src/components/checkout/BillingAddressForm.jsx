import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Receipt } from 'lucide-react';

const BillingAddressForm = ({ data, onChange, onNext, onBack, sameAsShipping, setSameAsShipping }) => {
  const [errors, setErrors] = useState({});

  const validate = () => {
    if (sameAsShipping) return true;
    
    const newErrs = {};
    if (!data.fullName) newErrs.fullName = "Full name is required";
    if (!data.address) newErrs.address = "Street address is required";
    if (!data.city) newErrs.city = "City is required";
    if (!data.state) newErrs.state = "State is required";
    if (!data.zip) newErrs.zip = "Postal code is required";
    
    setErrors(newErrs);
    return Object.keys(newErrs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) onNext();
  };

  return (
    <Card className="premium-card p-6 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6 border-b border-border pb-4">
        <h2 className="font-serif text-2xl font-bold flex items-center gap-2">
          <Receipt className="w-6 h-6 text-primary" />
          Billing Address
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex items-center space-x-2 bg-muted/50 p-4 rounded-xl border border-border">
          <Checkbox id="sameAsShipping" checked={sameAsShipping} onCheckedChange={setSameAsShipping} />
          <Label htmlFor="sameAsShipping" className="font-medium cursor-pointer">Billing address is same as shipping</Label>
        </div>

        {!sameAsShipping && (
          <div className="space-y-6 pt-4 animate-in fade-in slide-in-from-top-2">
            <div className="space-y-2">
              <Label htmlFor="b_fullName">Full Name</Label>
              <Input id="b_fullName" value={data.fullName || ''} onChange={(e) => onChange('fullName', e.target.value)} className={errors.fullName ? "border-destructive" : ""} />
              {errors.fullName && <p className="text-xs text-destructive">{errors.fullName}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="b_address">Street Address</Label>
              <Input id="b_address" value={data.address || ''} onChange={(e) => onChange('address', e.target.value)} className={errors.address ? "border-destructive" : ""} />
              {errors.address && <p className="text-xs text-destructive">{errors.address}</p>}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="col-span-2 space-y-2">
                <Label htmlFor="b_city">City</Label>
                <Input id="b_city" value={data.city || ''} onChange={(e) => onChange('city', e.target.value)} className={errors.city ? "border-destructive" : ""} />
                {errors.city && <p className="text-xs text-destructive">{errors.city}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="b_state">State</Label>
                <Input id="b_state" value={data.state || ''} onChange={(e) => onChange('state', e.target.value)} className={errors.state ? "border-destructive" : ""} />
                {errors.state && <p className="text-xs text-destructive">{errors.state}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="b_zip">Postal Code</Label>
                <Input id="b_zip" value={data.zip || ''} onChange={(e) => onChange('zip', e.target.value)} className={errors.zip ? "border-destructive" : ""} />
                {errors.zip && <p className="text-xs text-destructive">{errors.zip}</p>}
              </div>
            </div>
          </div>
        )}

        <div className="pt-6 flex justify-between items-center">
          <Button type="button" variant="ghost" onClick={onBack}>Back to Shipping</Button>
          <Button type="submit" size="lg" className="rounded-full px-8">Continue to Payment</Button>
        </div>
      </form>
    </Card>
  );
};

export default BillingAddressForm;