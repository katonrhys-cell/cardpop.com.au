import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext.jsx';

const ShippingAddressForm = ({ data, onChange, onNext }) => {
  const { isAuthenticated, currentUser } = useAuth();

  const handleSubmit = (e) => {
    e.preventDefault();
    onNext();
  };

  return (
    <form onSubmit={handleSubmit} className="bg-card border border-border rounded-2xl p-6 shadow-sm">
      <h2 className="text-2xl font-serif font-bold mb-6">Shipping Information</h2>
      
      <div className="space-y-4">
        {!isAuthenticated && (
          <div className="space-y-2 mb-6 pb-6 border-b border-border">
            <Label htmlFor="email">Email Address (for order updates)</Label>
            <Input 
              id="email" 
              type="email" 
              required 
              value={data.email || ''} 
              onChange={(e) => onChange('email', e.target.value)} 
              placeholder="guest@example.com"
              className="bg-background"
            />
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="firstName">First Name</Label>
            <Input 
              id="firstName" 
              required 
              value={data.firstName || ''} 
              onChange={(e) => onChange('firstName', e.target.value)} 
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lastName">Last Name</Label>
            <Input 
              id="lastName" 
              required 
              value={data.lastName || ''} 
              onChange={(e) => onChange('lastName', e.target.value)} 
              className="bg-background"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="address">Address</Label>
          <Input 
            id="address" 
            required 
            value={data.address || ''} 
            onChange={(e) => onChange('address', e.target.value)} 
            className="bg-background"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="city">City</Label>
            <Input 
              id="city" 
              required 
              value={data.city || ''} 
              onChange={(e) => onChange('city', e.target.value)} 
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="state">State / Province</Label>
            <Input 
              id="state" 
              required 
              value={data.state || ''} 
              onChange={(e) => onChange('state', e.target.value)} 
              className="bg-background"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="zipCode">ZIP / Postal Code</Label>
            <Input 
              id="zipCode" 
              required 
              value={data.zipCode || ''} 
              onChange={(e) => onChange('zipCode', e.target.value)} 
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="country">Country</Label>
            <Input 
              id="country" 
              required 
              value={data.country || ''} 
              onChange={(e) => onChange('country', e.target.value)} 
              className="bg-background"
            />
          </div>
        </div>
      </div>

      <div className="mt-8 flex justify-end">
        <Button type="submit" className="px-8 rounded-xl font-bold">
          Continue to Billing
        </Button>
      </div>
    </form>
  );
};

export default ShippingAddressForm;