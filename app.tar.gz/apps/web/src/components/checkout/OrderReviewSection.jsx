import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, ShieldCheck, Loader2 } from 'lucide-react';
import PromoCodeInput from './PromoCodeInput.jsx';

const OrderReviewSection = ({ 
  shippingData, 
  billingData, 
  sameAsShipping, 
  paymentMethod, 
  items, 
  subtotal, 
  tax, 
  discount, 
  total, 
  onConfirm, 
  onBack,
  processing,
  onApplyPromo
}) => {
  const billing = sameAsShipping ? shippingData : billingData;

  const getPaymentName = () => {
    if (paymentMethod === 'stripe') return 'Credit/Debit Card (Stripe)';
    if (paymentMethod === 'wallet') return 'Digital Wallet (Apple Pay/G Pay)';
    if (paymentMethod === 'razorpay') return 'Alternative (Razorpay)';
    return paymentMethod;
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <Card className="premium-card p-6 md:p-8">
        <div className="mb-6 border-b border-border pb-4 flex items-center justify-between">
          <h2 className="font-serif text-2xl font-bold flex items-center gap-2">
            <CheckCircle className="w-6 h-6 text-primary" />
            Review Your Order
          </h2>
          <Button variant="ghost" onClick={onBack} disabled={processing}>Edit Details</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="space-y-4">
            <h3 className="font-bold text-sm text-muted-foreground uppercase tracking-wider">Shipping To</h3>
            <div className="text-sm bg-muted/50 p-4 rounded-xl border border-border">
              <p className="font-semibold">{shippingData.fullName}</p>
              <p>{shippingData.address}</p>
              <p>{shippingData.city}, {shippingData.state} {shippingData.zip}</p>
              <p className="text-muted-foreground mt-2">{shippingData.email}</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-bold text-sm text-muted-foreground uppercase tracking-wider">Payment Details</h3>
            <div className="text-sm bg-muted/50 p-4 rounded-xl border border-border space-y-3">
              <div>
                <span className="text-muted-foreground block text-xs">Method</span>
                <span className="font-medium">{getPaymentName()}</span>
              </div>
              <div className="border-t border-border/50 pt-2">
                <span className="text-muted-foreground block text-xs">Billing Address</span>
                <p>{billing.address}, {billing.city} {billing.zip}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-bold text-sm text-muted-foreground uppercase tracking-wider mb-3">Promo Code</h3>
          <PromoCodeInput onApply={onApplyPromo} />
        </div>

        <div className="bg-primary/5 p-4 rounded-xl flex items-start gap-3 border border-primary/20">
          <ShieldCheck className="w-6 h-6 text-primary shrink-0" />
          <p className="text-sm text-foreground/80">
            <strong>Secure Transaction:</strong> Your payment details are encrypted. Funds are securely held until the order is complete.
          </p>
        </div>

      </Card>

      <Button 
        size="lg" 
        className="w-full h-14 rounded-full font-bold text-lg shadow-lg shadow-primary/20"
        onClick={onConfirm}
        disabled={processing}
      >
        {processing ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Processing Payment...
          </>
        ) : (
          `Confirm & Pay $${total.toFixed(2)}`
        )}
      </Button>
    </div>
  );
};

export default OrderReviewSection;