import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ShoppingCart, Edit2 } from 'lucide-react';

const OrderSummary = ({ cartItems, subtotal, tax, discount, total, onEditCart, onNext }) => {
  return (
    <Card className="premium-card p-6 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between mb-6 border-b border-border pb-4">
        <h2 className="font-serif text-2xl font-bold flex items-center gap-2">
          <ShoppingCart className="w-6 h-6 text-primary" />
          Order Summary
        </h2>
        <Button variant="ghost" size="sm" onClick={onEditCart} className="text-muted-foreground hover:text-primary">
          <Edit2 className="w-4 h-4 mr-2" /> Edit Cart
        </Button>
      </div>

      {cartItems.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">Your cart is empty.</div>
      ) : (
        <div className="space-y-6">
          <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-2">
            {cartItems.map((item, index) => {
              const price = item.variant?.sale_price_in_cents 
                ? item.variant.sale_price_in_cents / 100 
                : item.product.price || 0;
              const title = item.product.title || item.product.name;
              
              return (
                <div key={`${item.product.id}-${index}`} className="flex gap-4 group items-start">
                  <div className="w-16 h-20 bg-muted rounded-md overflow-hidden shrink-0 border border-border/50">
                    <img src={item.product.image || item.product.cardImage} alt={title} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0 py-1">
                    <h4 className="font-semibold text-foreground text-sm truncate">{title}</h4>
                    {item.variant?.title && item.variant.title !== 'Default Title' && (
                      <p className="text-xs text-muted-foreground mt-0.5">{item.variant.title}</p>
                    )}
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-xs font-medium bg-muted px-2 py-0.5 rounded-full text-muted-foreground">
                        Qty: {item.quantity}
                      </span>
                      <span className="font-semibold tabular-nums text-sm">
                        ${(price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="border-t border-border pt-4 space-y-3 text-sm">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span className="font-medium tabular-nums">${subtotal.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-success">
                <span>Discount applied</span>
                <span className="font-medium tabular-nums">-${discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-muted-foreground">
              <span>Estimated Tax (10%)</span>
              <span className="font-medium tabular-nums">${tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-end pt-4 border-t border-border mt-2">
              <span className="font-serif text-lg font-bold">Total</span>
              <span className="text-2xl font-bold tabular-nums text-primary">${total.toFixed(2)}</span>
            </div>
          </div>

          <Button onClick={onNext} size="lg" className="w-full rounded-full font-bold h-12 shadow-lg shadow-primary/20 hover:-translate-y-0.5 transition-transform">
            Continue to Shipping
          </Button>
        </div>
      )}
    </Card>
  );
};

export default OrderSummary;