
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import pb from '@/lib/pocketbaseClient.js';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Loader2, UploadCloud, X, AlertCircle, Sparkles } from 'lucide-react';
import { useCardAnalysis } from '@/hooks/useCardAnalysis.js';
import { useProductSelectors } from '@/hooks/useProductSelectors.js';

const INITIAL_STATE = {
  cardName: '',
  condition: 'Mint',
  estimatedValue: '',
  description: '',
  listingStatus: 'Not Listed',
  askingPrice: '',
  tradeValue: '',
};

const CardForm = ({ cardId, card: initialCard, onSuccess, onCancel }) => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(!!cardId && !initialCard);
  const [formData, setFormData] = useState(INITIAL_STATE);
  const [existingRecord, setExistingRecord] = useState(null);
  const [isAutoFilled, setIsAutoFilled] = useState(false);
  
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const fileInputRef = useRef(null);

  const { analyzeCardImage, isAnalyzing, analysisResult, clearAnalysis } = useCardAnalysis();

  const {
    brands,
    categories,
    filteredSubcategories,
    filteredProductLines,
    selectedBrand,
    selectedCategory,
    selectedSubcategory,
    selectedProductLine,
    setBrand,
    setCategory,
    setSubcategory,
    setProductLine,
    clearSubcategory,
    clearProductLine,
    loading: selectorsLoading
  } = useProductSelectors({
    brandId: initialCard?.brandId || '',
    categoryId: initialCard?.categoryId || '',
    subcategoryId: initialCard?.subcategoryId || '',
    productLineId: initialCard?.productLineId || ''
  });

  useEffect(() => {
    const initializeForm = async () => {
      let dataToMap = null;

      if (initialCard) {
        dataToMap = initialCard;
      } else if (cardId) {
        try {
          const record = await pb.collection('cards').getOne(cardId, { $autoCancel: false });
          dataToMap = record;
        } catch (error) {
          console.error("Failed to load card data:", error);
          toast.error("Failed to load card data");
          if (onCancel) onCancel();
        }
      }

      if (dataToMap) {
        setExistingRecord(dataToMap);
        setFormData({
          cardName: dataToMap.cardName ?? '',
          condition: dataToMap.condition ?? 'Mint',
          estimatedValue: dataToMap.estimatedValue ?? '',
          description: dataToMap.description ?? '',
          listingStatus: dataToMap.listingStatus ?? 'Not Listed',
          askingPrice: dataToMap.askingPrice ?? '',
          tradeValue: dataToMap.tradeValue ?? '',
        });

        if (dataToMap.brandId) setBrand(dataToMap.brandId);
        if (dataToMap.categoryId) setCategory(dataToMap.categoryId);
        if (dataToMap.subcategoryId) setSubcategory(dataToMap.subcategoryId);
        if (dataToMap.productLineId) setProductLine(dataToMap.productLineId);

        if (dataToMap.cardImage) {
          const imgField = Array.isArray(dataToMap.cardImage) ? dataToMap.cardImage[0] : dataToMap.cardImage;
          if (imgField) {
            setPreviewUrl(pb.files.getUrl(dataToMap, imgField));
          }
        }
      }
      setInitialLoading(false);
    };

    initializeForm();
  }, [cardId, initialCard, onCancel, setBrand, setCategory, setSubcategory, setProductLine]);

  const handleApplyAI = () => {
    if (!analysisResult) return;
    setFormData(prev => ({
      ...prev,
      cardName: analysisResult.cardName || prev.cardName,
      condition: analysisResult.mappedCondition || prev.condition,
      estimatedValue: analysisResult.estimatedValue ? String(analysisResult.estimatedValue) : prev.estimatedValue,
      description: [
        analysisResult.details,
        analysisResult.rarity ? `Rarity: ${analysisResult.rarity}` : '',
        analysisResult.cardType ? `Type: ${analysisResult.cardType}` : '',
        analysisResult.gradeScore ? `Grade: ${analysisResult.gradeScore}` : '',
        analysisResult.gradeCondition ? `Grade Condition: ${analysisResult.gradeCondition}` : ''
      ].filter(Boolean).join('\n') || prev.description
    }));
    setIsAutoFilled(true);
    toast.success("Fields auto-filled successfully. Please review and edit as needed.");
  };

  const handleClearAnalysis = () => {
    clearAnalysis();
    setIsAutoFilled(false);
  };

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 20971520) {
        toast.error('Image must be less than 20MB');
        return;
      }
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    if (!existingRecord?.cardImage) {
      setPreviewUrl(null);
    } else {
      const imgField = Array.isArray(existingRecord.cardImage) ? existingRecord.cardImage[0] : existingRecord.cardImage;
      setPreviewUrl(imgField ? pb.files.getUrl(existingRecord, imgField) : null);
    }
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const isEditMode = !!existingRecord?.id;

    if (!formData.cardName.trim()) {
      toast.error('Card Name is required');
      return;
    }
    if (!selectedBrand) {
      toast.error('Brand is required');
      return;
    }
    if (!selectedCategory) {
      toast.error('Category is required');
      return;
    }
    if (!formData.estimatedValue || isNaN(formData.estimatedValue)) {
      toast.error('A valid Estimated Value is required');
      return;
    }
    if (!currentUser) {
      toast.error('You must be logged in to add a card');
      return;
    }
    if (!currentUser.emailVerified) {
      toast.error('Email verification required. Please verify your email before adding cards to your vault.');
      return;
    }

    setLoading(true);
    try {
      const submitData = new FormData();
      
      if (!isEditMode) {
        submitData.append('owner', currentUser.id);
      }

      submitData.append('cardName', formData.cardName.trim());
      submitData.append('condition', formData.condition);
      submitData.append('estimatedValue', parseFloat(formData.estimatedValue));
      submitData.append('listingStatus', formData.listingStatus);
      
      submitData.append('brandId', selectedBrand);
      submitData.append('categoryId', selectedCategory);
      if (selectedSubcategory) submitData.append('subcategoryId', selectedSubcategory);
      if (selectedProductLine) submitData.append('productLineId', selectedProductLine);
      
      if (formData.description) submitData.append('description', formData.description.trim());
      
      if (formData.listingStatus === 'For Sale' || formData.listingStatus === 'For Both') {
        submitData.append('listedForSale', true);
        if (formData.askingPrice) submitData.append('askingPrice', parseFloat(formData.askingPrice));
      } else {
        submitData.append('listedForSale', false);
        submitData.append('askingPrice', '');
      }

      if (formData.listingStatus === 'For Trade' || formData.listingStatus === 'For Both') {
        submitData.append('listedForTrade', true);
        if (formData.tradeValue) submitData.append('tradeValue', parseFloat(formData.tradeValue));
      } else {
        submitData.append('listedForTrade', false);
        submitData.append('tradeValue', '');
      }

      if (selectedFile) {
        submitData.append('cardImage', selectedFile);
      }

      if (isEditMode) {
        await pb.collection('cards').update(existingRecord.id, submitData, { $autoCancel: false });
        toast.success('Card updated successfully!');
      } else {
        await pb.collection('cards').create(submitData, { $autoCancel: false });
        toast.success('Card added to your vault!');
        if (!onSuccess) {
          setFormData(INITIAL_STATE);
          setSelectedFile(null);
          setPreviewUrl(null);
          setIsAutoFilled(false);
          clearAnalysis();
        }
      }
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error("PocketBase Submission Error:", error);
      toast.error(error.message || `Failed to ${isEditMode ? 'update' : 'create'} card.`);
    } finally {
      setLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <div className="flex justify-center items-center py-16">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  const isEditMode = !!existingRecord?.id;

  return (
    <form onSubmit={handleSubmit} className="space-y-8 bg-card text-card-foreground">
      
      {!currentUser?.emailVerified && (
        <div className="bg-destructive/10 border border-destructive/20 text-destructive p-4 rounded-xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-sm">Email Verification Required</p>
            <p className="text-xs opacity-90">You must verify your email address before you can add cards to your vault.</p>
          </div>
        </div>
      )}

      <div className="space-y-4 bg-secondary p-6 rounded-2xl border border-border">
        <div className="flex items-center justify-between">
          <Label className="text-base font-bold text-foreground">
            Card Image
          </Label>
        </div>
        
        {previewUrl ? (
          <div className="relative w-full max-w-sm aspect-[3/4] rounded-xl overflow-hidden border-2 border-primary/20 bg-black/5 mx-auto group">
            <img src={previewUrl} alt="Preview" className="w-full h-full object-contain" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
              <div className="flex gap-4">
                <Button type="button" variant="secondary" size="sm" onClick={() => fileInputRef.current?.click()}>
                  Change Image
                </Button>
                {selectedFile && (
                  <Button type="button" variant="destructive" size="sm" onClick={clearFile}>
                    Revert
                  </Button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-full border-2 border-dashed border-border hover:border-primary/50 transition-colors rounded-xl p-12 flex flex-col items-center justify-center cursor-pointer bg-background text-muted-foreground hover:bg-muted"
          >
            <UploadCloud className="w-10 h-10 mb-4 opacity-50" />
            <p className="font-medium text-foreground mb-1">Click to upload image</p>
            <p className="text-xs">JPEG, PNG, WEBP (Max 20MB)</p>
          </div>
        )}
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          accept="image/jpeg, image/png, image/webp" 
          className="hidden" 
        />

        {selectedFile && !analysisResult && (
          <Button
            type="button"
            variant="secondary"
            onClick={() => analyzeCardImage(selectedFile)}
            disabled={isAnalyzing}
            className="w-full mt-4 bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 transition-all"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Sparkles className="w-4 h-4 mr-2" />}
            {isAnalyzing ? 'Analyzing Image...' : 'Analyze with AI'}
          </Button>
        )}

        {analysisResult && (
          <div className="mt-4 p-4 bg-primary/5 border border-primary/20 rounded-xl animate-in fade-in slide-in-from-top-2">
            <h4 className="font-bold text-sm text-primary mb-3 flex items-center">
              <Sparkles className="w-4 h-4 mr-2"/> AI Analysis Results
            </h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-foreground/80 mb-4">
              <div className="col-span-2"><strong className="text-foreground">Name:</strong> {analysisResult.cardName || 'N/A'}</div>
              <div><strong className="text-foreground">Category:</strong> {analysisResult.mappedType || 'N/A'}</div>
              <div><strong className="text-foreground">Condition:</strong> {analysisResult.mappedCondition || 'N/A'}</div>
              {analysisResult.estimatedValue && <div><strong className="text-foreground">Est. Value:</strong> ${analysisResult.estimatedValue}</div>}
              {analysisResult.gradeScore && <div><strong className="text-foreground">Grade:</strong> {analysisResult.gradeScore}</div>}
              {analysisResult.rarity && <div className="col-span-2"><strong className="text-foreground">Rarity:</strong> {analysisResult.rarity}</div>}
            </div>
            <div className="flex gap-2 pt-3 border-t border-primary/10">
              <Button type="button" size="sm" onClick={handleApplyAI} className="flex-1 font-semibold">
                Auto-fill Fields
              </Button>
              <Button type="button" size="sm" variant="outline" onClick={handleClearAnalysis} className="flex-1">
                Clear
              </Button>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
        
        <div className="space-y-6 md:col-span-2 bg-secondary p-6 rounded-2xl border border-border relative">
          {isAutoFilled && (
            <div className="absolute top-6 right-6 flex items-center text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-md">
              <Sparkles className="w-3 h-3 mr-1" />
              AI Auto-filled
            </div>
          )}
          <h3 className="font-bold text-lg text-foreground border-b border-border pb-2 pr-32">Basic Information</h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Card Name <span className="text-destructive">*</span></Label>
              <Input 
                required 
                value={formData.cardName} 
                onChange={(e) => handleInputChange('cardName', e.target.value)} 
                placeholder="e.g. Charizard Holographic" 
                className={`bg-background border-border transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`} 
              />
            </div>

            <div className="space-y-2">
              <Label>Condition <span className="text-destructive">*</span></Label>
              <Select value={formData.condition} onValueChange={(v) => handleInputChange('condition', v)}>
                <SelectTrigger className={`bg-background border-border transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mint">Mint</SelectItem>
                  <SelectItem value="Near Mint">Near Mint</SelectItem>
                  <SelectItem value="Excellent">Excellent</SelectItem>
                  <SelectItem value="Good">Good</SelectItem>
                  <SelectItem value="Fair">Fair</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Brand <span className="text-destructive">*</span></Label>
              <Select value={selectedBrand} onValueChange={setBrand} disabled={selectorsLoading}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue placeholder="Select Brand" />
                </SelectTrigger>
                <SelectContent>
                  {brands.map(b => (
                    <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Category <span className="text-destructive">*</span></Label>
              <Select value={selectedCategory} onValueChange={setCategory} disabled={selectorsLoading}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue placeholder="Select Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Product Line</Label>
                {selectedProductLine && (
                  <button type="button" onClick={clearProductLine} className="text-xs text-muted-foreground hover:text-foreground">Clear</button>
                )}
              </div>
              <Select value={selectedProductLine} onValueChange={setProductLine} disabled={!selectedBrand || selectorsLoading}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue placeholder={selectedBrand ? "Select Product Line" : "Select Brand first"} />
                </SelectTrigger>
                <SelectContent>
                  {filteredProductLines.map(pl => (
                    <SelectItem key={pl.id} value={pl.id}>{pl.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Subcategory</Label>
                {selectedSubcategory && (
                  <button type="button" onClick={clearSubcategory} className="text-xs text-muted-foreground hover:text-foreground">Clear</button>
                )}
              </div>
              <Select value={selectedSubcategory} onValueChange={setSubcategory} disabled={!selectedCategory || selectorsLoading}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue placeholder={selectedCategory ? "Select Subcategory" : "Select Category first"} />
                </SelectTrigger>
                <SelectContent>
                  {filteredSubcategories.map(sub => (
                    <SelectItem key={sub.id} value={sub.id}>{sub.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Estimated Value ($) <span className="text-destructive">*</span></Label>
              <Input 
                required 
                type="number" 
                step="0.01" 
                min="0" 
                value={formData.estimatedValue} 
                onChange={(e) => handleInputChange('estimatedValue', e.target.value)} 
                placeholder="0.00" 
                className={`bg-background border-border tabular-nums transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`} 
              />
            </div>
          </div>
        </div>

        <div className="space-y-4 md:col-span-2">
          <h3 className="font-bold text-lg text-foreground border-b border-border pb-2">Market Status</h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Listing Status <span className="text-destructive">*</span></Label>
              <Select value={formData.listingStatus} onValueChange={(v) => handleInputChange('listingStatus', v)}>
                <SelectTrigger className="bg-background border-border"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Not Listed">Not Listed</SelectItem>
                  <SelectItem value="For Trade">For Trade</SelectItem>
                  <SelectItem value="For Sale">For Sale</SelectItem>
                  <SelectItem value="For Both">For Both</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(formData.listingStatus === 'For Sale' || formData.listingStatus === 'For Both') && (
              <div className="space-y-2">
                <Label>Asking Price ($)</Label>
                <Input type="number" step="0.01" min="0" value={formData.askingPrice} onChange={(e) => handleInputChange('askingPrice', e.target.value)} placeholder="0.00" className="bg-background border-border" />
              </div>
            )}

            {(formData.listingStatus === 'For Trade' || formData.listingStatus === 'For Both') && (
              <div className="space-y-2">
                <Label>Trade Value ($)</Label>
                <Input type="number" step="0.01" min="0" value={formData.tradeValue} onChange={(e) => handleInputChange('tradeValue', e.target.value)} placeholder="0.00" className="bg-background border-border" />
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label>Card Description / Notes</Label>
          <Textarea 
            value={formData.description} 
            onChange={(e) => handleInputChange('description', e.target.value)} 
            placeholder="Add any specific details, centering notes, or historical context about this card..."
            className={`min-h-[100px] resize-y bg-background border-border transition-all ${isAutoFilled ? 'border-primary/50 ring-1 ring-primary/20' : ''}`}
          />
        </div>

      </div>

      <div className="flex items-center justify-end gap-4 pt-6 border-t border-border">
        {onCancel && (
          <Button type="button" variant="ghost" onClick={onCancel} disabled={loading}>
            Cancel
          </Button>
        )}
        <Button 
          type="submit" 
          disabled={loading || !currentUser?.emailVerified} 
          className="min-w-[150px] font-bold shadow-md"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
          {loading ? 'Saving...' : isEditMode ? 'Update Card' : 'Save to Vault'}
        </Button>
      </div>
    </form>
  );
};

export default CardForm;
