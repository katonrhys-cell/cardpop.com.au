import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';
import { Loader2, CalendarPlus as CalendarIcon, Clock, FileCode2, FileText, Type } from 'lucide-react';
import pb from '@/lib/pocketbaseClient.js';

const ArticleEditorModal = ({ isOpen, onClose, article, onSave }) => {
  const [loading, setLoading] = useState(false);
  const [contentType, setContentType] = useState('text'); // 'text', 'html', 'document'
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    status: 'draft',
    author: ''
  });
  
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  
  const [documentFile, setDocumentFile] = useState(null);
  const [documentFileName, setDocumentFileName] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (article) {
        setFormData({
          title: article.title || '',
          content: article.content || '',
          status: article.status || 'draft',
          author: article.author || ''
        });
        
        if (article.featuredImage) {
          setImagePreview(pb.files.getUrl(article, article.featuredImage));
        } else {
          setImagePreview(null);
        }

        if (article.article_document) {
          setDocumentFileName(article.article_document);
          if (article.article_document.endsWith('.html')) {
            setContentType('html');
          } else {
            setContentType('document');
          }
        } else {
          setContentType('text');
          setDocumentFileName('');
        }
      } else {
        setFormData({
          title: '',
          content: '',
          status: 'draft',
          author: pb.authStore.model?.name || pb.authStore.model?.email || 'Admin'
        });
        setImagePreview(null);
        setContentType('text');
        setDocumentFileName('');
      }
      setImageFile(null);
      setDocumentFile(null);
    }
  }, [isOpen, article]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleStatusChange = (value) => {
    setFormData(prev => ({ ...prev, status: value }));
  };

  const handleImageChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleDocumentChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setDocumentFile(file);
      setDocumentFileName(file.name);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      toast.error("Title is required.");
      return;
    }

    if (contentType === 'text' && !formData.content.trim()) {
      toast.error("Text content is required.");
      return;
    }

    if ((contentType === 'html' || contentType === 'document') && !documentFile && !article?.article_document) {
      toast.error("A document file is required for this content type.");
      return;
    }

    setLoading(true);
    try {
      const submitData = new FormData();
      submitData.append('title', formData.title);
      submitData.append('status', formData.status);
      
      if (!article?.id) {
        submitData.append('author', formData.author);
      }

      if (imageFile) {
        submitData.append('featuredImage', imageFile);
      }

      if (contentType === 'text') {
        submitData.append('content', formData.content);
        // PocketBase allows clearing files by sending empty string, but we'll just leave it or let it be overwritten if needed.
        // For strictness, we could clear article_document, but FormData doesn't easily clear files unless supported by backend.
      } else {
        submitData.append('content', ''); // Clear text content if using file
        if (documentFile) {
          submitData.append('article_document', documentFile);
        }
      }

      if (article?.id) {
        await pb.collection('articles').update(article.id, submitData, { $autoCancel: false });
        toast.success("Article updated successfully");
      } else {
        await pb.collection('articles').create(submitData, { $autoCancel: false });
        toast.success("Article created successfully");
      }
      
      onSave();
      onClose();
    } catch (err) {
      console.error("Error saving article:", err);
      toast.error(err.message || "Failed to save article");
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !loading && !open && onClose()}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold font-heading">
            {article ? 'View / Edit Article' : 'Create New Article'}
          </DialogTitle>
          <DialogDescription>
            {article ? 'Update the details and content of this article.' : 'Fill in the details below to publish a new article.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          {article && (
            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground bg-muted/30 p-3 rounded-lg border border-border">
              <div className="flex items-center gap-1.5">
                <CalendarIcon className="w-4 h-4" />
                <span>Created: {formatDate(article.created)}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>Updated: {formatDate(article.updated)}</span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="title" className="text-foreground font-medium">Article Title <span className="text-destructive">*</span></Label>
              <Input 
                id="title" 
                name="title" 
                value={formData.title} 
                onChange={handleChange} 
                placeholder="Enter article title..."
                className="bg-background text-foreground"
                disabled={loading}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="author" className="text-foreground font-medium">Author</Label>
              <Input 
                id="author" 
                name="author" 
                value={formData.author} 
                readOnly
                className="bg-muted text-muted-foreground cursor-not-allowed"
                disabled={true}
              />
              <p className="text-xs text-muted-foreground">Author cannot be changed.</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status" className="text-foreground font-medium">Status</Label>
              <Select value={formData.status} onValueChange={handleStatusChange} disabled={loading}>
                <SelectTrigger className="bg-background text-foreground">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="published">Published</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4 md:col-span-2 bg-muted/20 p-4 rounded-xl border border-border">
              <Label className="text-foreground font-medium">Content Format</Label>
              <RadioGroup 
                value={contentType} 
                onValueChange={setContentType}
                className="flex flex-col sm:flex-row gap-4"
                disabled={loading}
              >
                <div className="flex items-center space-x-2 bg-background p-3 rounded-lg border border-border flex-1 cursor-pointer hover:border-primary/50 transition-colors">
                  <RadioGroupItem value="text" id="type-text" />
                  <Label htmlFor="type-text" className="flex items-center gap-2 cursor-pointer flex-1">
                    <Type className="w-4 h-4 text-muted-foreground" /> Text Content
                  </Label>
                </div>
                <div className="flex items-center space-x-2 bg-background p-3 rounded-lg border border-border flex-1 cursor-pointer hover:border-primary/50 transition-colors">
                  <RadioGroupItem value="html" id="type-html" />
                  <Label htmlFor="type-html" className="flex items-center gap-2 cursor-pointer flex-1">
                    <FileCode2 className="w-4 h-4 text-muted-foreground" /> HTML File
                  </Label>
                </div>
                <div className="flex items-center space-x-2 bg-background p-3 rounded-lg border border-border flex-1 cursor-pointer hover:border-primary/50 transition-colors">
                  <RadioGroupItem value="document" id="type-document" />
                  <Label htmlFor="type-document" className="flex items-center gap-2 cursor-pointer flex-1">
                    <FileText className="w-4 h-4 text-muted-foreground" /> Document
                  </Label>
                </div>
              </RadioGroup>

              <div className="pt-2">
                {contentType === 'text' ? (
                  <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                    <Label htmlFor="content" className="text-foreground font-medium">Full Content <span className="text-destructive">*</span></Label>
                    <Textarea 
                      id="content" 
                      name="content" 
                      value={formData.content} 
                      onChange={handleChange} 
                      placeholder="Write the full article content here..."
                      className="bg-background text-foreground min-h-[250px] resize-y font-mono text-sm"
                      disabled={loading}
                    />
                  </div>
                ) : (
                  <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                    <Label htmlFor="article_document" className="text-foreground font-medium">
                      Upload {contentType === 'html' ? 'HTML' : 'Document'} File <span className="text-destructive">*</span>
                    </Label>
                    <Input 
                      id="article_document" 
                      name="article_document" 
                      type="file"
                      accept={contentType === 'html' ? 'text/html' : 'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document'}
                      onChange={handleDocumentChange} 
                      className="bg-background text-foreground file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer"
                      disabled={loading}
                    />
                    {documentFileName && (
                      <p className="text-sm text-muted-foreground mt-2 flex items-center gap-2">
                        Current file: <span className="font-medium text-foreground">{documentFileName}</span>
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      {contentType === 'html' ? 'Accepts .html files up to 20MB.' : 'Accepts .pdf, .doc, .docx files up to 20MB.'}
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="featuredImage" className="text-foreground font-medium">Featured Image</Label>
              <div className="flex flex-col sm:flex-row items-start gap-4">
                {imagePreview && (
                  <div className="relative w-full sm:w-40 aspect-video rounded-md overflow-hidden border border-border bg-muted shrink-0">
                    <img src={imagePreview} alt="Featured Preview" className="object-cover w-full h-full" />
                  </div>
                )}
                <div className="flex-1 w-full">
                  <Input 
                    id="featuredImage" 
                    name="featuredImage" 
                    type="file"
                    accept="image/jpeg,image/png,image/gif,image/webp"
                    onChange={handleImageChange} 
                    className="bg-background text-foreground file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20 cursor-pointer"
                    disabled={loading}
                  />
                  <p className="text-xs text-muted-foreground mt-2">Upload a new image to replace the current one.</p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="pt-4 border-t border-border flex sm:justify-between">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              Close
            </Button>
            <Button type="submit" disabled={loading} className="gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {article ? 'Save Changes' : 'Create Article'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ArticleEditorModal;