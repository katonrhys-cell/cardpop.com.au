import React from 'react';
import { Button } from '@/components/ui/button';
import { ShieldAlert, Trash2, Power } from 'lucide-react';

const BulkActionsBar = ({ selectedCount, onBulkDelete, onBulkStatusChange, onClearSelection }) => {
  if (selectedCount === 0) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-card border border-border shadow-lg rounded-full px-6 py-3 flex items-center gap-6 z-50 animate-in slide-in-from-bottom-5">
      <div className="flex items-center gap-2">
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-primary text-sm font-bold">
          {selectedCount}
        </span>
        <span className="text-sm font-medium text-foreground">Listings selected</span>
      </div>

      <div className="flex items-center gap-2 border-l border-border pl-6">
        <Button variant="outline" size="sm" onClick={onBulkStatusChange} className="rounded-full h-8 text-xs">
          <Power className="w-3.5 h-3.5 mr-1.5" />
          Change Status
        </Button>
        <Button variant="destructive" size="sm" onClick={onBulkDelete} className="rounded-full h-8 text-xs">
          <Trash2 className="w-3.5 h-3.5 mr-1.5" />
          Delete
        </Button>
        <Button variant="ghost" size="sm" onClick={onClearSelection} className="rounded-full h-8 text-xs text-muted-foreground">
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default BulkActionsBar;