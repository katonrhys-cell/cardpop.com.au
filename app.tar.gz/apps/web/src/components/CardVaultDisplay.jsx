
import React, { useState } from 'react';
import { Edit, Trash2, ImageOff, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient.js';

const CardVaultDisplay = ({ cards, loading, error, onEdit, onDelete, onStatusUpdate }) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="bg-card rounded-2xl p-4 border border-border shadow-sm flex flex-col h-[400px]">
            <Skeleton className="w-full aspect-[3/4] rounded-xl mb-4" />
            <Skeleton className="h-6 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2 mb-4" />
            <Skeleton className="h-12 w-full mt-auto rounded-xl" />
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12 bg-destructive/10 rounded-2xl border border-destructive/20">
        <p className="text-destructive font-semibold">Unable to display vault items at this time.</p>
      </div>
    );
  }

  if (!cards || cards.length === 0) {
    return (
      <div className="text-center py-20 bg-muted/20 rounded-3xl border border-dashed border-border/60">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <ImageOff className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-xl font-bold text-foreground mb-2">No cards found</h3>
        <p className="text-muted-foreground max-w-sm mx-auto">
          We couldn't find any cards matching your current filters, or your vault is empty.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {cards.map(card => {
        if (!card || !card.id) return null; // Defensive check for corrupt data
        return (
          <VaultCardItem 
            key={card.id} 
            card={card} 
            onEdit={() => onEdit && onEdit(card)} 
            onDelete={() => onDelete && onDelete(card.id)}
            onStatusUpdate={onStatusUpdate}
          />
        );
      })}
    </div>
  );
};

const VaultCardItem = ({ card, onEdit, onDelete, onStatusUpdate }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [status, setStatus] = useState(card?.listingStatus ?? 'Not Listed');
  const [price, setPrice] = useState(card?.askingPrice ?? card?.salePrice ?? '');
  const [isSaving, setIsSaving] = useState(false);
  
  // Safely determine array of images
  const rawImages = card?.cardImage;
  const images = Array.isArray(rawImages) ? rawImages : (rawImages ? [rawImages] : []);

  const nextImage = (e) => {
    e.stopPropagation();
    if (images.length > 0) {
      setCurrentImageIndex((prev) => (prev + 1) % images.length);
    }
  };

  const prevImage = (e) => {
    e.stopPropagation();
    if (images.length > 0) {
      setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
    }
  };

  const handleSaveStatus = async () => {
    setIsSaving(true);
    try {
      const updateData = {
        listingStatus: status,
        askingPrice: ['For Sale', 'For Both'].includes(status) ? Number(price) : null,
        salePrice: ['For Sale', 'For Both'].includes(status) ? Number(price) : null,
        listedForSale: ['For Sale', 'For Both'].includes(status),
        listedForTrade: ['For Trade', 'For Both'].includes(status)
      };

      await pb.collection('cards').update(card.id, updateData, { $autoCancel: false });
      toast.success('Listing status updated');
      if (onStatusUpdate) onStatusUpdate();
    } catch (err) {
      toast.error('Failed to update status');
    } finally {
      setIsSaving(false);
    }
  };

  // Generate valid URL with fallback
  let displayImageUrl = null;
  if (images.length > 0 && images[currentImageIndex]) {
    try {
      displayImageUrl = pb.files.getUrl(card, images[currentImageIndex]);
    } catch (error) {
      console.warn('Failed to generate image URL for card:', card?.id, error);
    }
  }

  const cardName = card?.cardName ?? 'Unknown Card';
  const collectionType = card?.collectionType ?? 'Other';
  const condition = card?.condition ?? 'Unknown Condition';
  const estimatedValue = Number(card?.estimatedValue ?? 0).toFixed(2);
  const currentStatus = card?.listingStatus ?? 'Not Listed';

  return (
    <div className="bg-card border border-border hover:border-primary/40 hover:shadow-md transition-all duration-300 rounded-2xl p-4 flex flex-col group h-full">
      <div className="aspect-[3/4] bg-muted/40 rounded-xl mb-4 overflow-hidden relative border border-border/50">
        {displayImageUrl ? (
          <>
            <img 
              src={displayImageUrl} 
              alt={cardName} 
              className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500" 
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIHZpZXdCb3g9IjAgMCAxMDAgMTAwIiBmaWxsPSJub25lIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjNmMTRiIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjOWNhM2FmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+SW1hZ2UgRXJyb3I8L3RleHQ+PC9zdmc+';
              }}
            />
            {images.length > 1 && (
              <>
                <div className="absolute inset-0 flex items-center justify-between px-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={prevImage} className="bg-black/50 hover:bg-black text-white rounded-full p-1.5 backdrop-blur-sm transition-colors">
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button onClick={nextImage} className="bg-black/50 hover:bg-black text-white rounded-full p-1.5 backdrop-blur-sm transition-colors">
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5 bg-black/40 px-2 py-1 rounded-full backdrop-blur-sm">
                  {images.map((_, idx) => (
                    <div key={idx} className={`w-1.5 h-1.5 rounded-full ${idx === currentImageIndex ? 'bg-white' : 'bg-white/40'}`} />
                  ))}
                </div>
              </>
            )}
          </>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
            <ImageOff className="w-10 h-10 mb-2 opacity-30" />
            <span className="text-xs font-bold uppercase tracking-wider opacity-60">No Image</span>
          </div>
        )}
        <div className="absolute top-3 right-3">
          <Badge variant={currentStatus !== 'Not Listed' ? 'default' : 'secondary'} className="shadow-md font-bold tracking-wide border-none bg-background/90 backdrop-blur-sm text-foreground">
            {currentStatus}
          </Badge>
        </div>
      </div>
      
      <h3 className="font-bold text-lg mb-1 leading-tight line-clamp-1 group-hover:text-primary transition-colors" title={cardName}>
        {cardName}
      </h3>
      
      <div className="text-sm text-muted-foreground mb-4 flex flex-wrap items-center gap-2">
        <Badge variant="outline" className="font-semibold text-xs bg-background">
          {collectionType}
        </Badge>
        <span className="truncate">{condition}</span>
      </div>

      <div className="mt-auto">
        <div className="flex items-end justify-between mb-4">
          <div className="flex flex-col">
            <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mb-0.5">Est. Value</span>
            <span className="font-extrabold text-foreground text-xl tabular-nums tracking-tight">
              ${estimatedValue}
            </span>
          </div>
        </div>

        <div className="flex gap-2 pt-4 border-t border-border/60">
          <Button variant="secondary" className="flex-1 font-bold rounded-xl active:scale-95 transition-transform" onClick={onEdit}>
            <Edit className="w-4 h-4 mr-2" /> Edit
          </Button>
          <Button variant="ghost" className="px-3 rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/10 active:scale-95 transition-transform" onClick={onDelete}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CardVaultDisplay;
