
import React from 'react';
import { GripVertical, Edit2, Trash2, ChevronRight, ChevronDown, Tag, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useDragDrop } from '@/hooks/useDragDrop.js';
import DropZoneContainer from './DropZoneContainer.jsx';

const BrandDragItem = ({ 
  brand, 
  expanded, 
  onToggle, 
  onEdit, 
  onDelete, 
  onAddChild,
  onDropSuccess,
  childCount = 0
}) => {
  const { handleDragStart, handleDragEnd } = useDragDrop();

  return (
    <DropZoneContainer 
      targetType="brand" 
      targetId={brand.id} 
      onDropSuccess={onDropSuccess}
      className="rounded-lg"
    >
      <div 
        draggable
        onDragStart={(e) => handleDragStart(e, brand, 'brand', brand.parentSubcategory)}
        onDragEnd={handleDragEnd}
        className="flex items-center gap-2 py-2 px-3 hover:bg-muted/30 rounded-lg transition-all group cursor-grab active:cursor-grabbing border border-transparent hover:border-border/50"
      >
        <div className="text-muted-foreground/20 group-hover:text-muted-foreground/60 transition-colors cursor-grab">
          <GripVertical className="w-3.5 h-3.5" />
        </div>
        
        <button onClick={onToggle} className="p-1 hover:bg-background rounded-md transition-colors shrink-0">
          {expanded ? <ChevronDown className="w-3.5 h-3.5 text-primary/60" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/70" />}
        </button>
        
        <div className="flex-1 flex items-center justify-between min-w-0">
          <div className="flex items-center gap-3 min-w-0">
            {brand.logo_url ? (
              <img src={brand.logo_url} alt={brand.name} className="w-5 h-5 rounded object-cover bg-white" />
            ) : (
              <Tag className="w-3.5 h-3.5 text-muted-foreground/70" />
            )}
            <span className="font-medium text-foreground text-sm truncate">{brand.name}</span>
            <span className="text-[10px] font-medium text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded-full tabular-nums">
              {childCount} series
            </span>
            {brand.website_url && (
              <a href={brand.website_url} target="_blank" rel="noopener noreferrer" className="text-muted-foreground/50 hover:text-primary transition-colors" onClick={(e) => e.stopPropagation()}>
                <Globe className="w-3 h-3" />
              </a>
            )}
          </div>
          
          <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity shrink-0 ml-4">
            <Button variant="ghost" size="sm" className="h-6 text-[10px] font-medium text-muted-foreground hover:text-primary" onClick={(e) => { e.stopPropagation(); onAddChild(brand, 'series'); }}>
              + Series
            </Button>
            <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground" onClick={(e) => { e.stopPropagation(); onEdit(brand, 'brand'); }}>
              <Edit2 className="w-3 h-3" />
            </Button>
            <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={(e) => { e.stopPropagation(); onDelete(brand, 'brand'); }}>
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </div>
    </DropZoneContainer>
  );
};

export default BrandDragItem;
