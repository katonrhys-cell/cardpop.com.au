
import React from 'react';
import { GripVertical, Edit2, Trash2, Hash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useDragDrop } from '@/hooks/useDragDrop.js';
import DropZoneContainer from './DropZoneContainer.jsx';

const SeriesDragItem = ({ 
  series, 
  onEdit, 
  onDelete,
  onDropSuccess
}) => {
  const { handleDragStart, handleDragEnd } = useDragDrop();

  return (
    <DropZoneContainer 
      targetType="series" 
      targetId={series.id} 
      onDropSuccess={onDropSuccess}
      className="rounded-md"
    >
      <div 
        draggable
        onDragStart={(e) => handleDragStart(e, series, 'series', series.parentBrand)}
        onDragEnd={handleDragEnd}
        className="flex items-center gap-2 py-1.5 px-3 hover:bg-muted/20 rounded-md transition-all group cursor-grab active:cursor-grabbing"
      >
        <div className="text-muted-foreground/20 group-hover:text-muted-foreground/50 transition-colors cursor-grab">
          <GripVertical className="w-3 h-3" />
        </div>
        
        <div className="w-5 shrink-0" /> {/* Spacer for alignment */}
        
        <div className="flex-1 flex items-center justify-between min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <Hash className="w-3 h-3 text-muted-foreground/50" />
            <span className="text-foreground text-sm truncate">{series.name}</span>
            {series.releaseYear && <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded font-mono">{series.releaseYear}</span>}
            {series.description && <span className="text-[10px] text-muted-foreground truncate max-w-[200px] hidden md:inline-block ml-2">- {series.description}</span>}
          </div>
          
          <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity shrink-0 ml-4">
            <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground" onClick={(e) => { e.stopPropagation(); onEdit(series, 'series'); }}>
              <Edit2 className="w-3 h-3" />
            </Button>
            <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive" onClick={(e) => { e.stopPropagation(); onDelete(series, 'series'); }}>
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </div>
    </DropZoneContainer>
  );
};

export default SeriesDragItem;
