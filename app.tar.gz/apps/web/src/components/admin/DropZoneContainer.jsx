
import React, { useState } from 'react';
import { useDragDrop } from '@/hooks/useDragDrop.js';
import { cn } from '@/lib/utils.js';

const DropZoneContainer = ({ 
  children, 
  targetType, 
  targetId, 
  onDropSuccess, 
  className = '' 
}) => {
  const [isOver, setIsOver] = useState(false);
  const [isValid, setIsValid] = useState(true);
  const { validateDropZone } = useDragDrop();

  const handleDragOver = (e) => {
    e.preventDefault(); 
    e.stopPropagation();
    
    try {
      setIsOver(true);
    } catch (err) {
      // Ignore errors parsing data during drag over
    }
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsOver(false);
    
    try {
      const dataStr = e.dataTransfer.getData('application/json');
      if (!dataStr) return;
      
      const draggedData = JSON.parse(dataStr);
      
      if (validateDropZone(draggedData.type, targetType)) {
        if (onDropSuccess) {
          onDropSuccess(draggedData, { targetType, targetId });
        }
      } else {
        setIsValid(false);
        setTimeout(() => setIsValid(true), 1000);
      }
    } catch (error) {
      console.error('Drop error:', error);
    }
  };

  const dropClasses = isOver 
    ? isValid 
      ? 'ring-2 ring-primary/50 bg-primary/10 shadow-sm z-10 relative scale-[1.01]' 
      : 'ring-2 ring-destructive bg-destructive/10 cursor-not-allowed z-10 relative' 
    : '';

  return (
    <div 
      className={cn("transition-all duration-200", dropClasses, className)}
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {children}
    </div>
  );
};

export default DropZoneContainer;
