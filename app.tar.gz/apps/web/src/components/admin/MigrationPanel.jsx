
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Database, AlertCircle, CheckCircle2, ShieldCheck, PlayCircle } from 'lucide-react';
import apiServerClient from '@/lib/apiServerClient.js';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

const MigrationPanel = ({ onMigrationComplete }) => {
  const [loading, setLoading] = useState(null);
  const [results, setResults] = useState(null);

  const handleMigration = async (endpoint, title) => {
    setLoading(endpoint);
    setResults(null);
    try {
      const response = await apiServerClient.fetch(`/migrate/${endpoint}`, {
        method: 'POST',
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Migration failed');
      }

      setResults({ title, ...data });
      toast.success(`${title} completed successfully`);
      if (onMigrationComplete && endpoint !== 'verify-hierarchy-integrity') {
        onMigrationComplete();
      }
    } catch (error) {
      console.error(`Migration error (${endpoint}):`, error);
      toast.error(`Error: ${error.message}`);
      setResults({ title, error: error.message });
    } finally {
      setLoading(null);
    }
  };

  const renderResults = () => {
    if (!results) return null;

    if (results.error) {
      return (
        <div className="mt-4 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-sm">
          <div className="flex items-center gap-2 text-destructive font-bold mb-2">
            <AlertCircle className="w-4 h-4" />
            {results.title} Failed
          </div>
          <p className="text-destructive/80">{results.error}</p>
        </div>
      );
    }

    return (
      <div className="mt-4 p-4 rounded-xl bg-card border border-border shadow-sm text-sm space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-border">
          <div className="flex items-center gap-2 text-foreground font-bold">
            <CheckCircle2 className="w-4 h-4 text-primary" />
            {results.title} Results
          </div>
          {results.dryRun && <Badge variant="secondary">Dry Run</Badge>}
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {results.summary && Object.entries(results.summary).map(([key, value]) => (
            <div key={key} className="flex flex-col">
              <span className="text-xs text-muted-foreground uppercase tracking-wider">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
              <span className="text-lg font-bold text-foreground tabular-nums">{value}</span>
            </div>
          ))}
        </div>

        {results.issues && results.issues.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-xs font-bold text-destructive uppercase tracking-wider mb-2">Issues Detected ({results.issues.length})</p>
            <ul className="list-disc list-inside text-muted-foreground space-y-1 max-h-32 overflow-y-auto">
              {results.issues.map((issue, idx) => (
                <li key={idx} className="truncate">{issue}</li>
              ))}
            </ul>
          </div>
        )}

        {results.errors && results.errors.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-xs font-bold text-destructive uppercase tracking-wider mb-2">Errors ({results.errors.length})</p>
            <ul className="list-disc list-inside text-muted-foreground space-y-1 max-h-32 overflow-y-auto">
              {results.errors.map((err, idx) => (
                <li key={idx} className="truncate">{typeof err === 'string' ? err : err.message || JSON.stringify(err)}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  };

  return (
    <Card className="border-border shadow-sm bg-muted/30">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          Legacy Data Migration
        </CardTitle>
        <CardDescription>
          Run these utilities to migrate old structural data into the new unified hierarchy format.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-3">
          <Button 
            variant="secondary" 
            onClick={() => handleMigration('copy-brands-to-hierarchy', 'Migrate Brands')}
            disabled={loading !== null}
            className="rounded-lg bg-background"
          >
            {loading === 'copy-brands-to-hierarchy' ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <PlayCircle className="w-4 h-4 mr-2 text-muted-foreground" />}
            Migrate Legacy Brands
          </Button>
          
          <Button 
            variant="secondary" 
            onClick={() => handleMigration('copy-card-sets-to-series', 'Migrate Card Sets')}
            disabled={loading !== null}
            className="rounded-lg bg-background"
          >
            {loading === 'copy-card-sets-to-series' ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <PlayCircle className="w-4 h-4 mr-2 text-muted-foreground" />}
            Migrate Card Sets to Series
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => handleMigration('verify-hierarchy-integrity', 'Hierarchy Integrity Check')}
            disabled={loading !== null}
            className="rounded-lg ml-auto"
          >
            {loading === 'verify-hierarchy-integrity' ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ShieldCheck className="w-4 h-4 mr-2 text-primary" />}
            Verify Integrity
          </Button>
        </div>
        
        {renderResults()}
      </CardContent>
    </Card>
  );
};

export default MigrationPanel;
