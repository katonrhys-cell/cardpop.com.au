
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import pb from '@/lib/pocketbaseClient.js';
import { toast } from 'sonner';

const UserActionsModal = ({ isOpen, onClose, actionType, user, onComplete }) => {
  const [loading, setLoading] = useState(false);
  const [reason, setReason] = useState('');
  const [confirmText, setConfirmText] = useState('');

  if (!user) return null;

  const handleAction = async () => {
    setLoading(true);
    try {
      if (actionType === 'suspend') {
        await pb.collection('users').update(user.id, { is_active: false, admin_notes: reason }, { $autoCancel: false });
        toast.success('User account suspended successfully.');
      } else if (actionType === 'unsuspend') {
        await pb.collection('users').update(user.id, { is_active: true }, { $autoCancel: false });
        toast.success('User account reactivated successfully.');
      } else if (actionType === 'reset_password') {
        await pb.collection('users').requestPasswordReset(user.email, { $autoCancel: false });
        toast.success('Password reset email sent to user.');
      } else if (actionType === 'delete') {
        if (confirmText !== user.email) {
          toast.error('Confirmation email does not match.');
          setLoading(false);
          return;
        }
        await pb.collection('users').delete(user.id, { $autoCancel: false });
        toast.success('User account deleted permanently.');
      }
      
      onComplete();
      onClose();
    } catch (error) {
      console.error("Action failed:", error);
      toast.error(error.message || 'Failed to perform action.');
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    switch (actionType) {
      case 'suspend':
        return (
          <div className="space-y-4 py-4">
            <DialogDescription>
              Suspending this account will prevent the user from logging in and hide their public listings.
            </DialogDescription>
            <div className="space-y-2">
              <Label>Reason for suspension (Internal)</Label>
              <Textarea 
                value={reason} 
                onChange={(e) => setReason(e.target.value)} 
                placeholder="e.g., Violation of terms of service..."
                className="resize-none"
              />
            </div>
          </div>
        );
      case 'unsuspend':
        return (
          <div className="py-4">
            <DialogDescription>
              This will restore the user's access to their account and reactivate their listings.
            </DialogDescription>
          </div>
        );
      case 'reset_password':
        return (
          <div className="py-4">
            <DialogDescription>
              A password reset link will be sent to <strong>{user.email}</strong>. The user will be required to set a new password on their next login.
            </DialogDescription>
          </div>
        );
      case 'delete':
        return (
          <div className="space-y-4 py-4">
            <DialogDescription className="text-destructive font-medium">
              Warning: This action is irreversible. It will permanently delete the user and cascade delete their vault items, but preserve order history for record-keeping.
            </DialogDescription>
            <div className="space-y-2">
              <Label>Type <strong>{user.email}</strong> to confirm</Label>
              <Input 
                value={confirmText} 
                onChange={(e) => setConfirmText(e.target.value)} 
                placeholder={user.email}
                className="border-destructive/50 focus-visible:ring-destructive"
              />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const getTitle = () => {
    switch (actionType) {
      case 'suspend': return 'Suspend User Account';
      case 'unsuspend': return 'Reactivate User Account';
      case 'reset_password': return 'Reset Password';
      case 'delete': return 'Delete User Account';
      default: return 'User Action';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-serif text-xl">{getTitle()}</DialogTitle>
        </DialogHeader>
        
        {renderContent()}

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={onClose} disabled={loading}>Cancel</Button>
          <Button 
            variant={actionType === 'delete' || actionType === 'suspend' ? 'destructive' : 'default'} 
            onClick={handleAction} 
            disabled={loading || (actionType === 'delete' && confirmText !== user.email)}
          >
            {loading ? 'Processing...' : 'Confirm Action'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default UserActionsModal;
