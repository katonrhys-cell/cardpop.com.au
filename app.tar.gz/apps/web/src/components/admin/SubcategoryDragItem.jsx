
import React from 'react';
import { GripVertical, Edit2, Trash2, ChevronRight, ChevronDown, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useDragDrop } from '@/hooks/useDragDrop.js';
import DropZoneContainer from './DropZoneContainer.jsx';

const SubcategoryDragItem = ({ 
  subcategory, 
  expanded, 
  onToggle, 
  onEdit, 
  onDelete, 
  onAddChild,
  onDropSuccess,
  childCount = 0
}) => {
  const { handleDragStart, handleDragEnd } = useDragDrop();

  return (
    <DropZoneContainer 
      targetType="subcategory" 
      targetId={subcategory.id} 
      onDropSuccess={onDropSuccess}
      className="rounded-lg"
    >
      <div 
        draggable
        onDragStart={(e) => handleDragStart(e, subcategory, 'subcategory', subcategory.parentCategory)}
        onDragEnd={handleDragEnd}
        className="flex items-center gap-2 py-2 px-3 bg-background hover:bg-muted/50 border border-transparent hover:border-border rounded-lg transition-all group cursor-grab active:cursor-grabbing"
      >
        <div className="text-muted-foreground/30 group-hover:text-muted-foreground/70 transition-colors cursor-grab">
          <GripVertical className="w-4 h-4" />
        </div>
        
        <button onClick={onToggle} className="p-1 hover:bg-background rounded-md transition-colors shrink-0">
          {expanded ? <ChevronDown className="w-4 h-4 text-primary/80" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
        </button>
        
        <div className="flex-1 flex items-center justify-between min-w-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <Layers className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="font-semibold text-foreground text-sm truncate">{subcategory.name}</span>
            <span className="text-[10px] font-medium text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded-full">
              {childCount} brands
            </span>
          </div>
          
          <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity shrink-0 ml-4">
            <Button variant="ghost" size="sm" className="h-7 text-xs font-medium text-muted-foreground hover:text-primary" onClick={(e) => { e.stopPropagation(); onAddChild(subcategory, 'brand'); }}>
              + Brand
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground" onClick={(e) => { e.stopPropagation(); onEdit(subcategory, 'subcategory'); }}>
              <Edit2 className="w-3.5 h-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={(e) => { e.stopPropagation(); onDelete(subcategory, 'subcategory'); }}>
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>
    </DropZoneContainer>
  );
};

export default SubcategoryDragItem;
