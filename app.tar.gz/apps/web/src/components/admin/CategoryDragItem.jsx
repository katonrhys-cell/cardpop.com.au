
import React from 'react';
import { GripVertical, Edit2, Trash2, ChevronRight, ChevronDown, FolderTree } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useDragDrop } from '@/hooks/useDragDrop.js';
import DropZoneContainer from './DropZoneContainer.jsx';

const CategoryDragItem = ({ 
  category, 
  expanded, 
  onToggle, 
  onEdit, 
  onDelete, 
  onAddChild,
  onDropSuccess,
  childCount = 0
}) => {
  const { handleDragStart, handleDragEnd } = useDragDrop();

  return (
    <DropZoneContainer 
      targetType="category" 
      targetId={category.id} 
      onDropSuccess={onDropSuccess}
      className="rounded-xl"
    >
      <div 
        draggable
        onDragStart={(e) => handleDragStart(e, category, 'category')}
        onDragEnd={handleDragEnd}
        className="flex items-center gap-2 py-3 px-4 bg-card border border-border rounded-xl hover:shadow-md transition-all group cursor-grab active:cursor-grabbing"
      >
        <div className="text-muted-foreground/50 group-hover:text-muted-foreground transition-colors cursor-grab">
          <GripVertical className="w-5 h-5" />
        </div>
        
        <button onClick={onToggle} className="p-1.5 hover:bg-muted rounded-md transition-colors shrink-0">
          {expanded ? <ChevronDown className="w-5 h-5 text-primary" /> : <ChevronRight className="w-5 h-5 text-muted-foreground" />}
        </button>
        
        <div className="flex-1 flex items-center justify-between min-w-0">
          <div className="flex items-center gap-3 min-w-0">
            <FolderTree className="w-4 h-4 text-primary/70" />
            <span className="font-bold text-foreground text-base truncate">{category.name}</span>
            <span className="text-xs font-medium text-muted-foreground bg-muted/50 px-2 py-0.5 rounded-full">
              {childCount} subcategories
            </span>
            {category.slug && <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-md font-mono hidden sm:inline-block">{category.slug}</span>}
          </div>
          
          <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity shrink-0 ml-4">
            <Button variant="ghost" size="sm" className="h-8 text-xs font-medium text-muted-foreground hover:text-primary" onClick={(e) => { e.stopPropagation(); onAddChild(category, 'subcategory'); }}>
              + Subcategory
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={(e) => { e.stopPropagation(); onEdit(category, 'category'); }}>
              <Edit2 className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={(e) => { e.stopPropagation(); onDelete(category, 'category'); }}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </DropZoneContainer>
  );
};

export default CategoryDragItem;
