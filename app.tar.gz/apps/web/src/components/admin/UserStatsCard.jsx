
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Package, ShoppingCart, Star, Clock, ShieldAlert, ShieldCheck } from 'lucide-react';

const UserStatsCard = ({ user, vaultProductsCount, ordersBuyerCount, ordersSellerCount, reviewsCount }) => {
  if (!user) return null;

  const accountAgeDays = Math.floor((new Date() - new Date(user.created)) / (1000 * 60 * 60 * 24));
  const lastLoginRelative = user.last_login 
    ? Math.floor((new Date() - new Date(user.last_login)) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <Card className="border-border shadow-sm rounded-2xl overflow-hidden">
      <CardHeader className="bg-muted/30 border-b border-border pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-serif">Activity Summary</CardTitle>
          <div className="flex gap-2">
            {user.is_active !== false ? (
              <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-200 gap-1">
                <ShieldCheck className="w-3 h-3" /> Active
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 gap-1">
                <ShieldAlert className="w-3 h-3" /> Suspended
              </Badge>
            )}
            {user.verified ? (
              <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-200">Verified</Badge>
            ) : (
              <Badge variant="outline" className="bg-muted text-muted-foreground">Unverified</Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Package className="w-4 h-4" />
              <span className="text-sm font-medium">Vault Items</span>
            </div>
            <p className="text-3xl font-bold">{vaultProductsCount || 0}</p>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <ShoppingCart className="w-4 h-4" />
              <span className="text-sm font-medium">Orders (B/S)</span>
            </div>
            <p className="text-3xl font-bold">{ordersBuyerCount || 0} / {ordersSellerCount || 0}</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Star className="w-4 h-4" />
              <span className="text-sm font-medium">Reviews Given</span>
            </div>
            <p className="text-3xl font-bold">{reviewsCount || 0}</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-medium">Account Age</span>
            </div>
            <p className="text-3xl font-bold">{accountAgeDays} <span className="text-base font-normal text-muted-foreground">days</span></p>
          </div>
        </div>

        <div className="mt-8 space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Profile Completion</span>
            <span className="font-medium">
              {user.name && user.avatar && user.location ? '100%' : '65%'}
            </span>
          </div>
          <Progress value={user.name && user.avatar && user.location ? 100 : 65} className="h-2" />
          <p className="text-xs text-muted-foreground mt-2">
            Last login: {lastLoginRelative !== null ? (lastLoginRelative === 0 ? 'Today' : `${lastLoginRelative} days ago`) : 'Never'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default UserStatsCard;
