import React, { useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient.js';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Monitor, MapPin, KeyRound, LogIn, AlertTriangle, ShieldCheck, ShieldAlert } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';

const EVENT_ICONS = {
  login: <LogIn className="w-4 h-4 text-[hsl(var(--info))]" />,
  failed_login: <AlertTriangle className="w-4 h-4 text-[hsl(var(--destructive))]" />,
  password_change: <KeyRound className="w-4 h-4 text-[hsl(var(--warning))]" />,
  mfa_enabled: <ShieldCheck className="w-4 h-4 text-[hsl(var(--success))]" />,
  mfa_disabled: <ShieldAlert className="w-4 h-4 text-[hsl(var(--destructive))]" />,
  suspicious_activity: <AlertTriangle className="w-4 h-4 text-[hsl(var(--destructive))]" />
};

const AuditLog = () => {
  const { currentUser } = useAuth();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const records = await pb.collection('auditLogs').getList(1, 15, {
        filter: `userId = "${currentUser.id}"`,
        sort: '-timestamp',
        $autoCancel: false
      });
      setLogs(records.items);
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser) {
      fetchLogs();
    }
  }, [currentUser]);

  return (
    <Card className="border-border shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between border-b border-border/50 pb-4">
        <div>
          <CardTitle className="text-xl">Security Events & Audit Log</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">Recent activity on your account</p>
        </div>
        <Button variant="ghost" size="icon" onClick={fetchLogs} disabled={loading} className="rounded-full">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        {loading && logs.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">Loading audit records...</div>
        ) : logs.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">No recent security events found.</div>
        ) : (
          <div className="divide-y divide-border">
            {logs.map((log) => (
              <div key={log.id} className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-muted/30 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-muted rounded-lg shrink-0 mt-0.5">
                    {EVENT_ICONS[log.eventType] || <AlertTriangle className="w-4 h-4 text-muted-foreground" />}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground capitalize tracking-wide text-sm mb-1">
                      {log.eventType.replace(/_/g, ' ')}
                    </p>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Monitor className="w-3 h-3" /> {log.deviceInfo || 'Unknown Device'}</span>
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {log.ipAddress || 'Unknown IP'}</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                  <Badge variant={log.status === 'success' ? 'default' : 'destructive'} className={log.status === 'success' ? 'bg-[hsl(var(--success))] hover:bg-[hsl(var(--success))]' : ''}>
                    {log.status}
                  </Badge>
                  <span className="text-xs text-muted-foreground font-medium" title={format(new Date(log.timestamp), 'PPpp')}>
                    {formatDistanceToNow(new Date(log.timestamp), { addSuffix: true })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AuditLog;