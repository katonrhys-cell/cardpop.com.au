import React from 'react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Lock, ArrowRightLeft, ShoppingCart } from 'lucide-react';
import { cn } from '@/lib/utils';

const CardListingOptions = ({ 
  listingStatus, 
  onListingStatusChange, 
  tradePrice, 
  onTradePriceChange, 
  salePrice, 
  onSalePriceChange,
  errors = {}
}) => {
  return (
    <div className="space-y-4">
      <RadioGroup 
        value={listingStatus} 
        onValueChange={onListingStatusChange}
        className="grid gap-4"
      >
        {/* Keep Private Option */}
        <div className={cn(
          "relative flex flex-col rounded-xl border-2 p-4 transition-all duration-200 cursor-pointer",
          listingStatus === 'Not Listed' 
            ? "border-primary bg-primary/5" 
            : "border-border bg-card hover:border-primary/30"
        )}>
          <RadioGroupItem value="Not Listed" id="status-private" className="sr-only" />
          <Label htmlFor="status-private" className="flex items-start gap-4 cursor-pointer w-full">
            <div className={cn(
              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors",
              listingStatus === 'Not Listed' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            )}>
              <Lock className="h-5 w-5" />
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-bold text-base">Keep Private</span>
              <span className="text-sm text-muted-foreground font-normal">
                Card remains in your vault. Only visible to you.
              </span>
            </div>
          </Label>
        </div>

        {/* Enable Trading Option */}
        <div className={cn(
          "relative flex flex-col rounded-xl border-2 p-4 transition-all duration-200 cursor-pointer",
          listingStatus === 'For Trade' 
            ? "border-primary bg-primary/5" 
            : "border-border bg-card hover:border-primary/30"
        )}>
          <RadioGroupItem value="For Trade" id="status-trade" className="sr-only" />
          <Label htmlFor="status-trade" className="flex items-start gap-4 cursor-pointer w-full">
            <div className={cn(
              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors",
              listingStatus === 'For Trade' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            )}>
              <ArrowRightLeft className="h-5 w-5" />
            </div>
            <div className="flex flex-col gap-1 w-full">
              <span className="font-bold text-base">Enable Trading</span>
              <span className="text-sm text-muted-foreground font-normal">
                List this card on the marketplace for trade offers.
              </span>
              
              <div className={cn("expand-content", listingStatus === 'For Trade' ? "expanded mt-4" : "")}>
                <div className="expand-inner">
                  <div className="space-y-2 pt-2">
                    <Label htmlFor="tradePrice" className="font-bold text-sm">Set Trade Value <span className="text-destructive">*</span></Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">$</span>
                      <Input 
                        id="tradePrice" 
                        type="number" 
                        min="0.01" 
                        step="0.01" 
                        placeholder="0.00" 
                        value={tradePrice}
                        onChange={(e) => onTradePriceChange(e.target.value)}
                        className={cn("pl-8 bg-background", errors.tradePrice && "border-destructive focus-visible:ring-destructive")}
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                    {errors.tradePrice && <p className="text-xs text-destructive font-medium">{errors.tradePrice}</p>}
                  </div>
                </div>
              </div>
            </div>
          </Label>
        </div>

        {/* Sell the Item Option */}
        <div className={cn(
          "relative flex flex-col rounded-xl border-2 p-4 transition-all duration-200 cursor-pointer",
          listingStatus === 'For Sale' 
            ? "border-primary bg-primary/5" 
            : "border-border bg-card hover:border-primary/30"
        )}>
          <RadioGroupItem value="For Sale" id="status-sell" className="sr-only" />
          <Label htmlFor="status-sell" className="flex items-start gap-4 cursor-pointer w-full">
            <div className={cn(
              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors",
              listingStatus === 'For Sale' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            )}>
              <ShoppingCart className="h-5 w-5" />
            </div>
            <div className="flex flex-col gap-1 w-full">
              <span className="font-bold text-base">Sell the Item</span>
              <span className="text-sm text-muted-foreground font-normal">
                List this card for direct purchase on the marketplace.
              </span>
              
              <div className={cn("expand-content", listingStatus === 'For Sale' ? "expanded mt-4" : "")}>
                <div className="expand-inner">
                  <div className="space-y-2 pt-2">
                    <Label htmlFor="salePrice" className="font-bold text-sm">Set Sale Price <span className="text-destructive">*</span></Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">$</span>
                      <Input 
                        id="salePrice" 
                        type="number" 
                        min="0.01" 
                        step="0.01" 
                        placeholder="0.00" 
                        value={salePrice}
                        onChange={(e) => onSalePriceChange(e.target.value)}
                        className={cn("pl-8 bg-background", errors.salePrice && "border-destructive focus-visible:ring-destructive")}
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                    {errors.salePrice && <p className="text-xs text-destructive font-medium">{errors.salePrice}</p>}
                  </div>
                </div>
              </div>
            </div>
          </Label>
        </div>
      </RadioGroup>
    </div>
  );
};

export default CardListingOptions;