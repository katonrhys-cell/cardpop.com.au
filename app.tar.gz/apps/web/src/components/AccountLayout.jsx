import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, User, Package, List, Tag, 
  ArrowRightLeft, Star, Wallet, Bookmark, 
  Bell, Shield, LogOut, Menu, MessageSquare 
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import pb from '@/lib/pocketbaseClient.js';

const NAV_ITEMS = [
  { label: 'Dashboard', path: '/account', icon: LayoutDashboard, exact: true },
  { label: 'Profile', path: '/profile', icon: User },
  { label: 'My Vault', path: '/vault', icon: Package },
  { label: 'Messaging', path: '/messaging', icon: MessageSquare },
  { label: 'Trade Requests', path: '/trade-requests', icon: ArrowRightLeft },
  { label: 'Listings', path: '/account/listings', icon: List },
  { label: 'Offers', path: '/account/offers', icon: Tag },
  { label: 'Reviews', path: '/account/reviews', icon: Star },
  { label: 'Wallet', path: '/account/wallet', icon: Wallet },
  { label: 'Watchlist', path: '/account/watchlist', icon: Bookmark },
  { label: 'Notifications', path: '/account/notifications', icon: Bell },
  { label: 'Security', path: '/account/security', icon: Shield },
];

const AccountLayout = () => {
  const { currentUser, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const isActive = (path, exact) => {
    if (exact) return location.pathname === path || location.pathname === path + '/';
    return location.pathname.startsWith(path);
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-4">
          <Avatar className="w-12 h-12 rounded-xl">
            <AvatarImage src={currentUser?.avatar ? pb.files.getUrl(currentUser, currentUser.avatar) : ''} />
            <AvatarFallback className="rounded-xl bg-primary/10 text-primary font-bold">
              {currentUser?.name?.charAt(0) || currentUser?.email?.charAt(0) || 'U'}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <h3 className="font-bold truncate">{currentUser?.name || 'User'}</h3>
            <p className="text-xs text-muted-foreground truncate">{currentUser?.email}</p>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path, item.exact);
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsMobileMenuOpen(false)}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                active 
                  ? 'bg-primary/10 text-primary font-bold' 
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              }`}
            >
              <Icon className="w-5 h-5" />
              {item.label}
            </Link>
          );
        })}
      </div>

      <div className="p-4 border-t border-border">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={handleLogout}
        >
          <LogOut className="w-5 h-5 mr-3" />
          Logout
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8">
        
        {/* Mobile Header & Menu Toggle */}
        <div className="md:hidden flex items-center justify-between bg-card p-4 rounded-2xl border border-border shadow-sm mb-4">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10 rounded-xl">
              <AvatarImage src={currentUser?.avatar ? pb.files.getUrl(currentUser, currentUser.avatar) : ''} />
              <AvatarFallback className="rounded-xl bg-primary/10 text-primary font-bold">
                {currentUser?.name?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-bold text-sm">My Account</h3>
            </div>
          </div>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-80">
              <SidebarContent />
            </SheetContent>
          </Sheet>
        </div>

        {/* Desktop Sidebar */}
        <aside className="hidden md:block w-64 shrink-0">
          <div className="bg-card border border-border rounded-2xl shadow-sm h-[calc(100vh-8rem)] sticky top-24 overflow-hidden flex flex-col">
            <SidebarContent />
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AccountLayout;