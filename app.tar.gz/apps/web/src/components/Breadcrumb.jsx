import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

const Breadcrumb = ({ items }) => {
  if (!items || items.length === 0) return null;

  return (
    <nav aria-label="Breadcrumb" className="seo-breadcrumb-nav mb-6 w-full max-w-full overflow-x-auto whitespace-nowrap hide-scrollbar">
      <ol className="flex items-center gap-1.5">
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          
          return (
            <li key={item.path || index} className="flex items-center gap-1.5">
              {index === 0 && <Home className="w-3.5 h-3.5" />}
              
              {isLast ? (
                <span className="font-semibold text-foreground" aria-current="page">
                  {item.label}
                </span>
              ) : (
                <>
                  <Link 
                    to={item.path} 
                    className="hover:text-primary transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded px-1"
                  >
                    {item.label}
                  </Link>
                  <ChevronRight className="w-3.5 h-3.5 opacity-50 shrink-0" />
                </>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

export default Breadcrumb;