import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { generateSlug } from '@/utils/categoryUtils.js';

const CategoryFilter = ({ hierarchy, currentCategory, currentSubcategory, basePath = '/vault' }) => {
  const location = useLocation();

  if (!hierarchy) return (
    <div className="seo-filter-sidebar animate-pulse">
      <div className="h-6 bg-muted rounded w-1/2 mb-4"></div>
      <div className="space-y-2">
        <div className="h-4 bg-muted rounded w-3/4"></div>
        <div className="h-4 bg-muted rounded w-2/3"></div>
      </div>
    </div>
  );

  return (
    <aside className="seo-filter-sidebar">
      <h3 className="font-bold font-heading text-lg mb-4">Categories</h3>
      
      <div className="space-y-4">
        {hierarchy.map((cat) => {
          const catSlug = generateSlug(cat.name) || cat.id;
          const isCatActive = currentCategory?.id === cat.id;
          
          return (
            <div key={cat.id} className="space-y-1">
              <Link
                to={`${basePath}/${catSlug}`}
                className={`block text-sm font-medium transition-colors hover:text-primary ${
                  isCatActive ? 'text-primary' : 'text-foreground'
                }`}
              >
                {cat.name}
              </Link>
              
              {isCatActive && cat.subcategories && cat.subcategories.length > 0 && (
                <div className="pl-3 border-l-2 border-muted ml-1 space-y-1 mt-1.5">
                  {cat.subcategories.map(sub => {
                    const subSlug = generateSlug(sub.name) || sub.id;
                    const isSubActive = currentSubcategory?.id === sub.id;
                    
                    return (
                      <div key={sub.id}>
                        <Link
                          to={`${basePath}/${catSlug}/${subSlug}`}
                          className={`block text-sm py-1 transition-colors hover:text-primary ${
                            isSubActive ? 'text-primary font-medium' : 'text-muted-foreground'
                          }`}
                        >
                          {sub.name}
                        </Link>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </aside>
  );
};

export default CategoryFilter;