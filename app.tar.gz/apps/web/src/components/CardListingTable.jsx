import React, { useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ExternalLink, ArrowUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export const CardListingTable = ({ data }) => {
  const [sortConfig, setSortConfig] = useState({ key: 'saleDate', direction: 'desc' });
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const sortedData = [...data].sort((a, b) => {
    if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
    if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });

  const totalPages = Math.ceil(sortedData.length / itemsPerPage);
  const paginatedData = sortedData.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  if (!data || data.length === 0) {
    return (
      <div className="text-center py-12 bg-muted/20 rounded-xl border border-dashed border-border">
        <p className="text-muted-foreground font-medium">No sales data found for the selected criteria.</p>
      </div>
    );
  }

  const SortIcon = () => <ArrowUpDown className="w-3 h-3 ml-1 inline-block opacity-50" />;

  return (
    <div className="w-full">
      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/30 text-muted-foreground uppercase tracking-wider font-bold text-xs">
              <th className="p-4 cursor-pointer hover:text-foreground transition-colors" onClick={() => handleSort('cardName')}>
                Card Details <SortIcon />
              </th>
              <th className="p-4 cursor-pointer hover:text-foreground transition-colors" onClick={() => handleSort('collectionType')}>
                Collection <SortIcon />
              </th>
              <th className="p-4 cursor-pointer hover:text-foreground transition-colors" onClick={() => handleSort('condition')}>
                Condition <SortIcon />
              </th>
              <th className="p-4 cursor-pointer hover:text-foreground transition-colors text-right" onClick={() => handleSort('soldPrice')}>
                Sold Price <SortIcon />
              </th>
              <th className="p-4 cursor-pointer hover:text-foreground transition-colors" onClick={() => handleSort('saleDate')}>
                Date <SortIcon />
              </th>
              <th className="p-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {paginatedData.map((item, idx) => (
              <tr key={idx} className="hover:bg-muted/20 transition-colors group">
                <td className="p-4">
                  <p className="font-bold text-foreground line-clamp-1">{item.cardName}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Seller: {item.sellerLocation || 'AU'}</p>
                </td>
                <td className="p-4">
                  <Badge variant="secondary" className="bg-primary/10 text-primary border-none font-bold">
                    {item.collectionType}
                  </Badge>
                </td>
                <td className="p-4">
                  <span className="font-medium">{item.condition}</span>
                  {item.grade && <span className="ml-2 text-xs text-muted-foreground">({item.grade})</span>}
                </td>
                <td className="p-4 text-right font-bold tabular-nums text-foreground">
                  ${Number(item.soldPrice).toFixed(2)}
                </td>
                <td className="p-4 text-muted-foreground tabular-nums">
                  {format(parseISO(item.saleDate), 'MMM d, yyyy')}
                </td>
                <td className="p-4 text-right">
                  <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-primary" asChild>
                    <a href={item.ebayUrl || '#'} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4" />
                      <span className="sr-only">View on eBay</span>
                    </a>
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 px-2">
          <p className="text-sm text-muted-foreground">
            Showing <span className="font-bold text-foreground">{(page - 1) * itemsPerPage + 1}</span> to <span className="font-bold text-foreground">{Math.min(page * itemsPerPage, sortedData.length)}</span> of <span className="font-bold text-foreground">{sortedData.length}</span> results
          </p>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              Previous
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};