
import React, { useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  Users, 
  FolderTree,
  Settings,
  Menu,
  X,
  LogOut,
  ShoppingCart,
  BarChart3,
  Home
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import pb from '@/lib/pocketbaseClient.js';

const NAV_ITEMS = [
  { name: 'Dashboard', path: '/admin', icon: LayoutDashboard, exact: true },
  { name: 'User Management', path: '/admin/users', icon: Users },
  { name: 'Product Management', path: '/admin/products', icon: Package },
  { name: 'Order Management', path: '/admin/orders', icon: ShoppingCart },
  { name: 'Category Management', path: '/admin/categories', icon: FolderTree },
  { name: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
  { name: 'Settings', path: '/admin/settings', icon: Settings },
];

const SidebarContent = ({ closeMenu }) => {
  const location = useLocation();

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 p-4">
      <div className="mb-8 px-2 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight">Admin Portal</h2>
          <p className="text-sm text-slate-400">Manage your platform</p>
        </div>
        {closeMenu && (
          <Button variant="ghost" size="icon" onClick={closeMenu} className="lg:hidden text-slate-400 hover:text-white hover:bg-white/10">
            <X className="w-5 h-5" />
          </Button>
        )}
      </div>
      <nav className="flex-1 space-y-1.5 overflow-y-auto pb-20">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = item.exact 
            ? location.pathname === item.path 
            : location.pathname.startsWith(item.path);

          return (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={closeMenu}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive 
                  ? 'bg-primary text-primary-foreground shadow-sm' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-slate-50'
              }`}
            >
              <Icon className="w-5 h-5" />
              {item.name}
            </NavLink>
          );
        })}
      </nav>
    </div>
  );
};

const AdminLayout = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const userInitials = currentUser?.name 
    ? currentUser.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
    : currentUser?.email?.substring(0, 2).toUpperCase() || 'AD';

  const avatarUrl = currentUser?.avatar ? pb.files.getUrl(currentUser, currentUser.avatar) : null;

  return (
    <div className="flex min-h-[calc(100vh-4rem)] bg-muted/30 w-full">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 flex-shrink-0 sticky top-16 h-[calc(100vh-4rem)] z-10 border-r border-border">
        <SidebarContent />
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header Bar */}
        <header className="flex items-center justify-between p-4 bg-background border-b border-border sticky top-16 z-20 shadow-sm">
          <div className="flex items-center gap-3">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" aria-label="Open admin menu" className="lg:hidden rounded-xl">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-[280px] border-none bg-slate-950">
                <SheetTitle className="sr-only">Admin Navigation Menu</SheetTitle>
                <SidebarContent closeMenu={() => setIsMobileMenuOpen(false)} />
              </SheetContent>
            </Sheet>
            <h1 className="font-semibold text-lg lg:hidden">Admin Portal</h1>
            <Button variant="ghost" size="sm" onClick={() => navigate('/')} className="hidden lg:flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <Home className="w-4 h-4" /> Back to Site
            </Button>
          </div>

          {/* User Menu */}
          <div className="flex items-center gap-4 ml-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 flex items-center gap-2 rounded-xl hover:bg-muted pl-2 pr-4">
                  <Avatar className="h-7 w-7">
                    <AvatarImage src={avatarUrl} alt={currentUser?.name || 'Admin'} />
                    <AvatarFallback className="bg-primary/10 text-primary text-xs font-bold">{userInitials}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col items-start text-left hidden sm:flex">
                    <span className="text-sm font-semibold leading-none">{currentUser?.name || 'Administrator'}</span>
                    <span className="text-xs text-muted-foreground leading-none mt-1">{currentUser?.role || 'Admin'}</span>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 rounded-xl border-border shadow-lg">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{currentUser?.name || 'Administrator'}</p>
                    <p className="text-xs leading-none text-muted-foreground">{currentUser?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/')} className="cursor-pointer rounded-lg">
                  <Home className="w-4 h-4 mr-2 text-muted-foreground" />
                  Back to Main Site
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer rounded-lg text-destructive focus:text-destructive focus:bg-destructive/10">
                  <LogOut className="w-4 h-4 mr-2" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-x-hidden w-full">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
